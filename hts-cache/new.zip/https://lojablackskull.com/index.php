

<!doctype html>
<html class="no-js" lang="pt-BR">
  <head><meta name="facebook-domain-verification" content="p5jon8kdstfl2eurm9ftfyoyweub3q" />
  
        
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="theme-color" content="#000000">
    <link href="https://use.fontawesome.com/releases/v5.0.1/css/all.css" rel="stylesheet"><title>OFICIAL BLACK SKULL BRASIL</title><link rel="canonical" href=""><link rel="preload" as="style" href="theme.css">
    <link rel="preconnect" href="https://cdn.shopify.com">
    <link rel="preconnect" href="https://fonts.shopifycdn.com">
    <link rel="dns-prefetch" href="https://productreviews.shopifycdn.com">
    <link rel="dns-prefetch" href="https://ajax.googleapis.com">
    <link rel="dns-prefetch" href="https://maps.googleapis.com">
    <link rel="dns-prefetch" href="https://maps.gstatic.com">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
   
    
      <script>
    window.onload = function () {
        function AlihunterBlockDM() {
            var All = document.getElementsByTagName('div');
            for (var i = 0; i < All.length; i++) {
                if (All[i].getAttribute('style') && All[i].getAttribute('style').includes('var(--ah-zIndex-backdrop)')) {
                    All[i - 2].style.display = "none";
                    return;
                }
            }
        }

        //Dropmeta por dropmeta.com.br
        AlihunterBlockDM()
    }
</script>

    
    
    <meta property="og:type" content="website">
  <meta property="og:title" ><meta property="og:url" content="">
<meta property="og:site_name" ><meta name="twitter:card" content="summary"><meta name="twitter:title" >
  <meta name="twitter:description" >
    <link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_n4.934accbf9f5987aa89334210e6c1e9151f37d3b6.woff2?&hmac=a26c177067467710b799e13b71d5721f54b5f733f905988a09d37a77232f0126" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_i4.a7e8d886e15d5fb9bc964a53b3278effbf270e9c.woff2?&hmac=bf8a78a8eb2fef7c9c25222b1451819ef48c692226fc1e8bad19e26309ff1778" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_n4.934accbf9f5987aa89334210e6c1e9151f37d3b6.woff2?&hmac=a26c177067467710b799e13b71d5721f54b5f733f905988a09d37a77232f0126" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_n7.58aca33913fc6666cc9e8a53f6b16ec5c3c05a3f.woff2?&hmac=8d9dd384d209499b478bf98b5485682c900079f51dff31fd22117f7f73d1adda" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_i4.a7e8d886e15d5fb9bc964a53b3278effbf270e9c.woff2?&hmac=bf8a78a8eb2fef7c9c25222b1451819ef48c692226fc1e8bad19e26309ff1778" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_i7.4f85a5d51a1aecf426eea47ac4570ef7341bfdc1.woff2?&hmac=3cff90516677e3e1b51fff62f501c532957073988956c933941fa7be666a6f06" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/font-theme-star.woff2?v=176977276741202493121664292914" as="font" type="font/woff2" crossorigin><link rel="preload" href="https://fonts.shopifycdn.com/poppins/poppins_n6.e2fdd168541a5add2d1a8d6f2b89b09c9c9e690d.woff2?&hmac=070e2cd74b7ec49cf30bdef0e50787089feaa27225ce611013fd06d4ca01553c" as="font" type="font/woff2" crossorigin><style>
  /* We load the font used for the integration with Shopify Reviews to load our own stars */
  @font-face {
    font-family: "font-theme-star";
    src: url(//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/font-theme-star.eot?v=178649971611478077551664292913);
    src: url(//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/font-theme-star.eot?%23iefix&v=178649971611478077551664292913) format("embedded-opentype"), url(//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/font-theme-star.woff2?v=176977276741202493121664292914) format("woff2"), url(//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/font-theme-star.ttf?v=17527569363257290761664292914) format("truetype");
    font-weight: normal;
    font-style: normal;
    font-display: fallback;
  }

  @font-face {
  font-family: Poppins;
  font-weight: 400;
  font-style: normal;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_n4.934accbf9f5987aa89334210e6c1e9151f37d3b6.woff2?&hmac=a26c177067467710b799e13b71d5721f54b5f733f905988a09d37a77232f0126") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_n4.ee28d4489eaf5de9cf6e17e696991b5e9148c716.woff?&hmac=f99517b82b6da9de0cdfe8aceb40e4132652b5e3e3d1c3b0906fe722b210b3bf") format("woff");
}

  @font-face {
  font-family: Poppins;
  font-weight: 400;
  font-style: normal;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_n4.934accbf9f5987aa89334210e6c1e9151f37d3b6.woff2?&hmac=a26c177067467710b799e13b71d5721f54b5f733f905988a09d37a77232f0126") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_n4.ee28d4489eaf5de9cf6e17e696991b5e9148c716.woff?&hmac=f99517b82b6da9de0cdfe8aceb40e4132652b5e3e3d1c3b0906fe722b210b3bf") format("woff");
}

@font-face {
  font-family: Poppins;
  font-weight: 600;
  font-style: normal;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_n6.e2fdd168541a5add2d1a8d6f2b89b09c9c9e690d.woff2?&hmac=070e2cd74b7ec49cf30bdef0e50787089feaa27225ce611013fd06d4ca01553c") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_n6.6d62d2d0f11a9ff578d200ad2154f9860db165c1.woff?&hmac=a495883fa0fc3470c933bcf888dab412c02adbee6b4d4d2a4c901b077ddacf01") format("woff");
}

@font-face {
  font-family: Poppins;
  font-weight: 400;
  font-style: italic;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_i4.a7e8d886e15d5fb9bc964a53b3278effbf270e9c.woff2?&hmac=bf8a78a8eb2fef7c9c25222b1451819ef48c692226fc1e8bad19e26309ff1778") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_i4.e87de252199e27825a41bf81646996685d86452d.woff?&hmac=220b519190126252fb1d07281d9281e0af228c722333eb1aa0e4e7a8b71562db") format("woff");
}


  @font-face {
  font-family: Poppins;
  font-weight: 700;
  font-style: normal;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_n7.58aca33913fc6666cc9e8a53f6b16ec5c3c05a3f.woff2?&hmac=8d9dd384d209499b478bf98b5485682c900079f51dff31fd22117f7f73d1adda") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_n7.59016f931f3f39434d2e458fba083eb7db7a07d9.woff?&hmac=a0a4a74efb931c7132a3c607f37b39af6fd1456988c215c0931d93fb078d2658") format("woff");
}

  @font-face {
  font-family: Poppins;
  font-weight: 400;
  font-style: italic;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_i4.a7e8d886e15d5fb9bc964a53b3278effbf270e9c.woff2?&hmac=bf8a78a8eb2fef7c9c25222b1451819ef48c692226fc1e8bad19e26309ff1778") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_i4.e87de252199e27825a41bf81646996685d86452d.woff?&hmac=220b519190126252fb1d07281d9281e0af228c722333eb1aa0e4e7a8b71562db") format("woff");
}

  @font-face {
  font-family: Poppins;
  font-weight: 700;
  font-style: italic;
  font-display: fallback;
  src: url("https://fonts.shopifycdn.com/poppins/poppins_i7.4f85a5d51a1aecf426eea47ac4570ef7341bfdc1.woff2?&hmac=3cff90516677e3e1b51fff62f501c532957073988956c933941fa7be666a6f06") format("woff2"),
       url("https://fonts.shopifycdn.com/poppins/poppins_i7.aff3a08a92d1c136586c611b9fc43d357dfbbefe.woff?&hmac=c3a20c77e29f3f9718c99e5540f32a666dbe42055b66d23747f6f8ab106aa588") format("woff");
}


  :root {
    --default-text-font-size : 15px;
    --base-text-font-size    : 15px;
    --heading-font-family    : Poppins, sans-serif;
    --heading-font-weight    : 400;
    --heading-font-style     : normal;
    --text-font-family       : Poppins, sans-serif;
    --text-font-weight       : 400;
    --text-font-style        : normal;
    --text-font-bolder-weight: 600;
    --text-link-decoration   : underline;

    --text-color               : #737b97;
    --text-color-rgb           : 115, 123, 151;
    --heading-color            : #737b97;
    --border-color             : #e7e7e7;
    --border-color-rgb         : 231, 231, 231;
    --form-border-color        : #dadada;
    --accent-color             : #333333;
    --accent-color-rgb         : 0, 84, 255;
    --link-color               : #874dff;
    --link-color-hover         : #5300ff;
    --background               : #f7f7f7;
    --secondary-background     : #ffffff;
    --secondary-background-rgb : 255, 255, 255;
    --accent-background        : rgba(0, 84, 255, 0.08);
    --corstars                 : #ffce00;
    --cordabarra               : #00d864;
    --cordotexto               : #ffffff;

      
    --error-color       : #f71b1b;
    --error-background  : rgba(247, 27, 27, 0.07);
    --success-color     : #00d864;
    --success-background: rgba(0, 216, 100, 0.11);

    --primary-button-background      : #333333;
    --primary-button-background-rgb  : 0, 84, 255;
    --primary-button-text-color      : #ffffff;
    --secondary-button-background    : #702dfa;
    --secondary-button-background-rgb: 112, 45, 250;
    --secondary-button-text-color    : #ffffff;

    --footer-background        : #202020;
    --footer-text-color        : #cfcfcf;
    
    --header-background      : #202020;
    --header-text-color      : #737b97;
    --header-light-text-color: #7a00ff;
    --header-border-color    : rgba(122, 0, 255, 0.3);
    --header-accent-color    : #38bcff;

    --flickity-arrow-color: #b4b4b4;--product-on-sale-accent           : #333333;
    --product-on-sale-accent-rgb       : 0, 84, 255;
    --product-on-sale-color            : #ffffff;
    --product-cor-do-preco             : #00d864;
    --product-cor-do-preco-riscado     : #a4a9be;
    --product-cor-dos-titles           : #0076ff;
    --product-in-stock-color           : #00d864;
    --product-low-stock-color          : #ee0000;
    --product-sold-out-color           : #d1d1d4;
    --product-custom-label-1-background: #ff6128;
    --product-custom-label-1-color     : #ffffff;
    --product-custom-label-2-background: #a95ebe;
    --product-custom-label-2-color     : #ffffff;
    --product-review-star-color        : #ffb647;

    --mobile-container-gutter : 20px;
    --desktop-container-gutter: 40px;
  }
</style>

<script>
  // IE11 does not have support for CSS variables, so we have to polyfill them
  if (!(((window || {}).CSS || {}).supports && window.CSS.supports('(--a: 0)'))) {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = 'https://cdn.jsdelivr.net/npm/css-vars-ponyfill@2';
    script.onload = function() {
      cssVars({});
    };

    document.getElementsByTagName('head')[0].appendChild(script);
  }
</script>

    <script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script><meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/66500395261/digital_wallets/dialog">
<meta name="shopify-checkout-api-token" content="68e5851873c0e83c560dc9d64b6aa0f4">
<meta id="in-context-paypal-metadata" data-shop-id="66500395261" data-venmo-supported="false" data-environment="production" data-locale="pt_BR" data-paypal-v4="true" data-currency="BRL">


<script type="module">!function(o){(o.Shopify=o.Shopify||{}).modules=!0}(window);</script>
<script>!function(o){function n(){var o=[];function n(){o.push(Array.prototype.slice.apply(arguments))}return n.q=o,n}var t=o.Shopify=o.Shopify||{};t.loadFeatures=n(),t.autoloadFeatures=n()}(window);</script>
<script id="__st">var __st={"a":66500395261,"offset":-10800,"reqid":"41ca539a-ae82-45ab-8c4a-983a4ab38228","pageurl":"descomplica-magazine.myshopify.com\/","u":"5d76577e0a83","p":"home"};</script>
<script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
<script>!function(o){o.addEventListener("DOMContentLoaded",function(){window.Shopify=window.Shopify||{},window.Shopify.recaptchaV3=window.Shopify.recaptchaV3||{siteKey:"6LcCR2cUAAAAANS1Gpq_mDIJ2pQuJphsSQaUEuc9"};var t=['form[action*="/contact"] input[name="form_type"][value="contact"]','form[action*="/comments"] input[name="form_type"][value="new_comment"]','form[action*="/account"] input[name="form_type"][value="customer_login"]','form[action*="/account"] input[name="form_type"][value="recover_customer_password"]','form[action*="/account"] input[name="form_type"][value="create_customer"]','form[action*="/contact"] input[name="form_type"][value="customer"]'].join(",");function n(e){e=e.target;null==e||null!=(e=function e(t,n){if(null==t.parentElement)return null;if("FORM"!=t.parentElement.tagName)return e(t.parentElement,n);for(var o=t.parentElement.action,r=0;r<n.length;r++)if(-1!==o.indexOf(n[r]))return t.parentElement;return null}(e,["/contact","/comments","/account"]))&&null!=e.querySelector(t)&&((e=o.createElement("script")).setAttribute("src","https://cdn.shopify.com/shopifycloud/storefront-recaptcha-v3/v0.6/index.js"),o.body.appendChild(e),o.removeEventListener("focus",n,!0),o.removeEventListener("change",n,!0),o.removeEventListener("click",n,!0))}o.addEventListener("click",n,!0),o.addEventListener("change",n,!0),o.addEventListener("focus",n,!0)})}(document);</script>

<script integrity="sha256-qzgBevPPdZ2wrwu9HnUin2oYn1vx8ttCFpYwmYuWkCE=" data-source-attribution="shopify.loadfeatures" defer="defer" src="//cdn.shopify.com/shopifycloud/shopify/assets/storefront/load_feature-ab38017af3cf759db0af0bbd1e75229f6a189f5bf1f2db42169630998b969021.js" crossorigin="anonymous"></script>
<script integrity="sha256-h+g5mYiIAULyxidxudjy/2wpCz/3Rd1CbrDf4NudHa4=" data-source-attribution="shopify.dynamic-checkout" defer="defer" src="//cdn.shopify.com/shopifycloud/shopify/assets/storefront/features-87e8399988880142f2c62771b9d8f2ff6c290b3ff745dd426eb0dfe0db9d1dae.js" crossorigin="anonymous"></script>
<script integrity="sha256-AjT+yRYgO8z0L66BMKoqBvO4SrOWLJYnYYWthdsOhP4=" defer="defer" src="//cdn.shopify.com/shopifycloud/shopify/assets/storefront/bars/admin_bar_injector-0234fec916203bccf42fae8130aa2a06f3b84ab3962c96276185ad85db0e84fe.js" crossorigin="anonymous"></script>


<style id="shopify-dynamic-checkout-cart">@media screen and (min-width: 750px) {
  #dynamic-checkout-cart {
    min-height: 50px;
  }
}

@media screen and (max-width: 750px) {
  #dynamic-checkout-cart {
    min-height: 60px;
  }
}
</style><script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>
    
 




      <style>
.search-bar__submit {background: #333333!important;}
.header__cart-count {background: #333333!important;}
.section__title::after {background: #333333!important;}
.product-item__label-list > .product-label {background: #333333!important;}
.section__action-link {color: #333333!important;}
.text-with-icons__title {color: #2f2c35!important;}
#shopify-section-1649913264519d35a7 .button {color: black !important;}
.discount__percentage {background: #2f2c35!important;color: white!important;}
.product-label--on-sale {background: #2f2c35!important;color: white!important;}
.button--primary {background: #2f2c35!important;color: white!important;}
@media (max-width: 768px){
.botaoflutuante {background: #2f2c35!important;color: white!important;}}
.section__title::after{background: #333333!important;}
.price--highlight {color: #2f2c35!important;}
      </style>




 
<script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script><meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/66500395261/digital_wallets/dialog">
<meta name="shopify-checkout-api-token" content="68e5851873c0e83c560dc9d64b6aa0f4">
<meta id="in-context-paypal-metadata" data-shop-id="66500395261" data-venmo-supported="false" data-environment="production" data-locale="pt_BR" data-paypal-v4="true" data-currency="BRL">
<script id="shopify-features" type="application/json">{"accessToken":"68e5851873c0e83c560dc9d64b6aa0f4","betas":["rich-media-storefront-analytics"],"domain":"descomplica-magazine.myshopify.com","predictiveSearch":true,"shopId":66500395261,"smart_payment_buttons_url":"https:\/\/cdn.shopify.com\/shopifycloud\/payment-sheet\/assets\/latest\/spb.pt-br.js?v=2","dynamic_checkout_cart_url":"https:\/\/cdn.shopify.com\/shopifycloud\/payment-sheet\/assets\/latest\/dynamic-checkout-cart.pt-br.js?v=2","locale":"pt-br"}
<script type="module">!function(o){(o.Shopify=o.Shopify||{}).modules=!0}(window);</script>
<script>!function(o){function n(){var o=[];function n(){o.push(Array.prototype.slice.apply(arguments))}return n.q=o,n}var t=o.Shopify=o.Shopify||{};t.loadFeatures=n(),t.autoloadFeatures=n()}(window);</script>
<script id="__st">var __st={"a":66500395261,"offset":-10800,"reqid":"41ca539a-ae82-45ab-8c4a-983a4ab38228","pageurl":"descomplica-magazine.myshopify.com\/","u":"5d76577e0a83","p":"home"};</script>
<script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
<script>!function(o){o.addEventListener("DOMContentLoaded",function(){window.Shopify=window.Shopify||{},window.Shopify.recaptchaV3=window.Shopify.recaptchaV3||{siteKey:"6LcCR2cUAAAAANS1Gpq_mDIJ2pQuJphsSQaUEuc9"};var t=['form[action*="/contact"] input[name="form_type"][value="contact"]','form[action*="/comments"] input[name="form_type"][value="new_comment"]','form[action*="/account"] input[name="form_type"][value="customer_login"]','form[action*="/account"] input[name="form_type"][value="recover_customer_password"]','form[action*="/account"] input[name="form_type"][value="create_customer"]','form[action*="/contact"] input[name="form_type"][value="customer"]'].join(",");function n(e){e=e.target;null==e||null!=(e=function e(t,n){if(null==t.parentElement)return null;if("FORM"!=t.parentElement.tagName)return e(t.parentElement,n);for(var o=t.parentElement.action,r=0;r<n.length;r++)if(-1!==o.indexOf(n[r]))return t.parentElement;return null}(e,["/contact","/comments","/account"]))&&null!=e.querySelector(t)&&((e=o.createElement("script")).setAttribute("src","https://cdn.shopify.com/shopifycloud/storefront-recaptcha-v3/v0.6/index.js"),o.body.appendChild(e),o.removeEventListener("focus",n,!0),o.removeEventListener("change",n,!0),o.removeEventListener("click",n,!0))}o.addEventListener("click",n,!0),o.addEventListener("change",n,!0),o.addEventListener("focus",n,!0)})}(document);</script>

<script integrity="sha256-qzgBevPPdZ2wrwu9HnUin2oYn1vx8ttCFpYwmYuWkCE=" data-source-attribution="shopify.loadfeatures" defer="defer" data-src="//cdn.shopify.com/shopifycloud/shopify/assets/storefront/load_feature-ab38017af3cf759db0af0bbd1e75229f6a189f5bf1f2db42169630998b969021.js" crossorigin="anonymous"></script>
<script integrity="sha256-h+g5mYiIAULyxidxudjy/2wpCz/3Rd1CbrDf4NudHa4=" data-source-attribution="shopify.dynamic-checkout" defer="defer" data-src="//cdn.shopify.com/shopifycloud/shopify/assets/storefront/features-87e8399988880142f2c62771b9d8f2ff6c290b3ff745dd426eb0dfe0db9d1dae.js" crossorigin="anonymous"></script>
<script integrity="sha256-AjT+yRYgO8z0L66BMKoqBvO4SrOWLJYnYYWthdsOhP4=" defer="defer" data-src="//cdn.shopify.com/shopifycloud/shopify/assets/storefront/bars/admin_bar_injector-0234fec916203bccf42fae8130aa2a06f3b84ab3962c96276185ad85db0e84fe.js" crossorigin="anonymous"></script>
<!-- section assets 5a0084fc4d2a811d --><!-- shopify-dynamic-checkout 62eb559fe7ed27f2 --><!-- dynamic-checkout-cart ee9cd53b90e5a9bb --><script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>
	
    <link rel="stylesheet" href="theme.css">

    


    
  

    
    <script>
      // This allows to expose several variables to the global scope, to be used in scripts
      window.theme = {
        pageType: "index",
        cartCount: 0,
        moneyFormat: "R$ {{amount_with_comma_separator}}",
        moneyWithCurrencyFormat: "R$ {{amount_with_comma_separator}} BRL",
        showDiscount: true,
        discountMode: "percentage",
        searchMode: "product",
        cartType: "page"
      };

      window.routes = {
        rootUrl: "\/",
        cartUrl: "\/cart",
        cartAddUrl: "\/cart\/add",
        cartChangeUrl: "\/cart\/change",
        searchUrl: "\/search",
        productRecommendationsUrl: "\/recommendations\/products"
      };

      window.languages = {
        collectionOnSaleLabel: "{{savings}}",
        productFormUnavailable: "Indisponível",
        productFormAddToCart: "Comprar agora",
        productFormSoldOut: "Esgotado",
        shippingEstimatorNoResults: "Nenhum método de envio encontrado para o seu endereço.",
        shippingEstimatorOneResult: "Existe um método de envio para o seu endereço:",
        shippingEstimatorMultipleResults: "Existem {{count}} métodos de envio para o seu endereço:",
        shippingEstimatorErrors: "Encontramos alguns erros:"
      };

      window.lazySizesConfig = {
        loadHidden: false,
        hFac: 0.8,
        expFactor: 3,
        customMedia: {
          '--phone': '(max-width: 640px)',
          '--tablet': '(min-width: 641px) and (max-width: 1023px)',
          '--lap': '(min-width: 1024px)'
        }
      };

      document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
    </script><script src="//cdn.polyfill.io/v3/polyfill.min.js?unknown=polyfill&features=fetch,Element.prototype.closest,Element.prototype.matches,Element.prototype.remove,Element.prototype.classList,Array.prototype.includes,Array.prototype.fill,String.prototype.includes,String.prototype.padStart,Object.assign,CustomEvent,Intl,URL,DOMTokenList,IntersectionObserver,IntersectionObserverEntry" defer></script><!--thi@gohsil@--> 
    <script src="//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/theme.min.js?v=129998125763450196711664292914" defer></script>
    <script src="//cdn.shopify.com/s/files/1/0665/0039/5261/t/3/assets/custom.js?v=112171511692518087411664292913" defer></script><script>
        (function () {
          window.onpageshow = function() {
            // We force re-freshing the cart content onpageshow, as most browsers will serve a cache copy when hitting the
            // back button, which cause staled data
            document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
              bubbles: true,
              detail: {scrollToTop: false}
            }));
          };
        })();
      </script><link href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />

    <script>
    
    
    
    
    
    
    var gsf_conversion_data = {page_type : 'home', event : 'page_view', data : {product_data : [{variant_id : 43407755477245, product_id : 7898298188029, name : "Aspirador de Pó e Água WAP GTW 10 1400W 140mbar Compacto e Robusto com Soprador", price : "129.90", currency : "BRL", sku : "", brand : "Viva Lar", variant : "Default Title", category : ""}, {variant_id : 43407756394749, product_id : 7898299105533, name : "Conjunto de Panelas 7 Peças Tramontina Paris com Antiaderente", price : "169.90", currency : "BRL", sku : "", brand : "ciadolarcenter", variant : "Default Title", category : ""}], total_price :"299.80", shop_currency : "BRL"}};
    
    
</script>

  	  
<!-- RYVIU APP :: Settings global -->	
    <script> var ryviu_global_settings = ;</script>
<!-- RYVIU APP -->
<link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
<script>(function(){if ("sendBeacon" in navigator && "performance" in window) {var session_token = document.cookie.match(/_shopify_s=([^;]*)/);function handle_abandonment_event(e) {var entries = performance.getEntries().filter(function(entry) {return /monorail-edge.shopifysvc.com/.test(entry.name);});if (!window.abandonment_tracked && entries.length === 0) {window.abandonment_tracked = true;var currentMs = Date.now();var navigation_start = performance.timing.navigationStart;var payload = {shop_id: 66500395261,url: window.location.href,navigation_start,duration: currentMs - navigation_start,session_token: session_token && session_token.length === 2 ? session_token[1] : "",page_type: "index"};window.navigator.sendBeacon("https://monorail-edge.shopifysvc.com/v1/produce", JSON.stringify({schema_id: "online_store_buyer_site_abandonment/1.1",payload: payload,metadata: {event_created_at_ms: currentMs,event_sent_at_ms: currentMs}}));}}window.addEventListener('pagehide', handle_abandonment_event);}}());</script>
<script>window.ShopifyAnalytics = window.ShopifyAnalytics || {};
window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
window.ShopifyAnalytics.meta.currency = 'BRL';
var meta = {"page":{"pageType":"home"}};
for (var attr in meta) {
  window.ShopifyAnalytics.meta[attr] = meta[attr];
}</script>
<script>window.ShopifyAnalytics.merchantGoogleAnalytics = function() {
  
};
</script>

</head>

  <body class="warehouse--v1  template-index " data-instant-intensity="viewport"><!--thi@gohsil@-->  

    <span class="loading-bar"></span>

    <div id="shopify-section-announcement-bar" class="shopify-section"><section data-section-id="announcement-bar" data-section-type="announcement-bar" data-section-settings='{
    "showNewsletter": false
  }'><div class="announcement-bar">
      <div class="container">
        <div class="announcement-bar__inner"><div>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" fill="white" viewbox="0 0 512 264" style="margin-top: -6px; margin-bottom: -6px; margin-right: 12px;" width="18" height="37"><g>
            <path d="M490.727,21.379C473.083,3.489,447.355-3.846,422.93,2.051L96.786,70.595C34.85,79.76-7.929,137.399,1.236,199.334   c3.563,24.079,14.782,46.372,31.997,63.581l34.965,34.987c1.637,1.615,2.552,3.823,2.539,6.123v64.512   c0.047,40.134,32.57,72.657,72.704,72.704h64.512c2.303,0,4.513,0.913,6.144,2.539l34.965,34.965   c21.142,21.282,49.895,33.259,79.893,33.28c12.383-0.01,24.683-2.035,36.416-5.995c40.491-13.447,69.914-48.61,76.011-90.837   l68.544-325.12C516.084,65.391,508.789,39.291,490.727,21.379z M66.599,167c5.798-17.913,21.444-30.848,40.128-33.173   c0.754-0.1,1.5-0.228,2.24-0.384L393.17,73.71L134.738,331.992v-27.968c0.047-19.294-7.637-37.803-21.333-51.392l-34.923-34.965   C65.031,204.511,60.399,184.765,66.599,167z M378.535,403.118c-0.171,0.747-0.277,1.493-0.384,2.24   c-3.705,27.023-28.614,45.926-55.637,42.221c-10.676-1.464-20.581-6.379-28.203-13.997l-34.944-34.944   c-13.596-13.7-32.112-21.383-51.413-21.333h-27.968l258.368-258.432L378.535,403.118z"></path></g>
            </svg>
          </div>ENTREGA EXPRESSA PARA TODO BRASIL
</div>
      </div>
    </div>
  </section>


  <style>
    .announcement-bar {
      background-image: linear-gradient(to right, #000000, #000000);
      color: #ffffff;
    }
    
  </style>

  <script>document.documentElement.style.removeProperty('--announcement-bar-button-width');document.documentElement.style.setProperty('--announcement-bar-height', document.getElementById('shopify-section-announcement-bar').clientHeight + 'px');
  </script></div>
<div id="shopify-section-popups" class="shopify-section"><div data-section-id="popups" data-section-type="popups"></div>

</div>
<div id="shopify-section-header" class="shopify-section shopify-section__header"><section data-section-id="header" data-section-type="header" data-section-settings='{
  "navigationLayout": "inline",
  "desktopOpenTrigger": "hover",
  "useStickyHeader": false
}'><header class="header header--inline " role="banner">
    <div class="container">
      <div class="header__inner"><nav class="header__mobile-nav hidden-lap-and-up">
            <button class="header__mobile-nav-toggle icon-state touch-area" data-action="toggle-menu" aria-expanded="false" aria-haspopup="true" aria-controls="mobile-menu" aria-label="Abrir menu">
              <span class="icon-state__primary"><svg class="icon icon--hamburger-mobile" viewBox="0 0 20 16" role="presentation">
      <path d="M0 14h20v2H0v-2zM0 0h20v2H0V0zm0 7h20v2H0V7z" fill="currentColor" fill-rule="evenodd"></path>
    </svg></span>
              <span class="icon-state__secondary"><svg class="icon icon--close" viewBox="0 0 19 19" role="presentation">
      <path d="M9.1923882 8.39339828l7.7781745-7.7781746 1.4142136 1.41421357-7.7781746 7.77817459 7.7781746 7.77817456L16.9705627 19l-7.7781745-7.7781746L1.41421356 19 0 17.5857864l7.7781746-7.77817456L0 2.02943725 1.41421356.61522369 9.1923882 8.39339828z" fill="currentColor" fill-rule="evenodd"></path>
    </svg></span>
            </button><div id="mobile-menu" class="mobile-menu" aria-hidden="true"><svg class="icon icon--nav-triangle-borderless" viewBox="0 0 20 9" role="presentation">
      <path d="M.47108938 9c.2694725-.26871321.57077721-.56867841.90388257-.89986354C3.12384116 6.36134886 5.74788116 3.76338565 9.2467995.30653888c.4145057-.4095171 1.0844277-.40860098 1.4977971.00205122L19.4935156 9H.47108938z" fill="#ffffff"></path>
    </svg><div class="mobile-menu__inner">
    <div class="mobile-menu__panel">
      <div class="mobile-menu__section">
        <ul class="mobile-menu__nav" data-type="menu"><li class="mobile-menu__nav-item"><a href="/" class="mobile-menu__nav-link" data-type="menuitem">Início</a></li><li class="mobile-menu__nav-item"><a href="/produtos.php" class="mobile-menu__nav-link" data-type="menuitem">Catálogo</a></li><li class="mobile-menu__nav-item"><a href="/contato/" class="mobile-menu__nav-link" data-type="menuitem">Entrar em contato</a></li></ul>
      </div><div class="mobile-menu__section mobile-menu__section--loose">
          <p class="mobile-menu__section-title heading h5">Precisa de ajuda?</p><div class="mobile-menu__help-wrapper"><svg class="icon icon--bi-phone" viewBox="0 0 24 24" role="presentation">
      <g stroke-width="2" fill="none" fill-rule="evenodd" stroke-linecap="square">
        <path d="M17 15l-3 3-8-8 3-3-5-5-3 3c0 9.941 8.059 18 18 18l3-3-5-5z" stroke="#737b97"></path>
        <path d="M14 1c4.971 0 9 4.029 9 9m-9-5c2.761 0 5 2.239 5 5" stroke="#333333"></path>
      </g>
    </svg><span>21959515865</span>
            </div><div class="mobile-menu__help-wrapper"><svg class="icon icon--bi-email" viewBox="0 0 22 22" role="presentation">
      <g fill="none" fill-rule="evenodd">
        <path stroke="#333333" d="M.916667 10.08333367l3.66666667-2.65833334v4.65849997zm20.1666667 0L17.416667 7.42500033v4.65849997z"></path>
        <path stroke="#737b97" stroke-width="2" d="M4.58333367 7.42500033L.916667 10.08333367V21.0833337h20.1666667V10.08333367L17.416667 7.42500033"></path>
        <path stroke="#737b97" stroke-width="2" d="M4.58333367 12.1000003V.916667H17.416667v11.1833333m-16.5-2.01666663L21.0833337 21.0833337m0-11.00000003L11.0000003 15.5833337"></path>
        <path d="M8.25000033 5.50000033h5.49999997M8.25000033 9.166667h5.49999997" stroke="#333333" stroke-width="2" stroke-linecap="square"></path>
      </g>
    </svg><a href="mailto:contato@lojadescomplica.com.br">atendimento@lojablackskull.com</a>
            </div></div></div></div>
</div></nav><div class="header__logo"><a href="/" class="header__logo-link"><img class="header__logo-image"
                   style="max-width: 225px"
                   width="801"
                   height="246"
                   src="//cdn.shopify.com/s/files/1/0707/0973/9838/files/logo_200x@2x.png?v=1673904283"
                   alt="OFICIAL BLACK SKULL BRASIL"></a></div><div class="header__search-bar-wrapper ">
          <form action="" method="get" role="search" class="search-bar"><div class="search-bar__top-wrapper">
              <div class="search-bar__top">
                <input type="hidden" name="type" value="product">
                <input type="hidden" name="options[prefix]" value="last">

                <div class="search-bar__input-wrapper">
                  <input class="search-bar__input" type="text" name="q" autocomplete="off" autocorrect="off" aria-label="O que está buscando?" placeholder="O que está buscando?">
                  <button type="button" class="search-bar__input-clear hidden-lap-and-up" data-action="clear-input"><svg class="icon icon--close" viewBox="0 0 19 19" role="presentation">
      <path d="M9.1923882 8.39339828l7.7781745-7.7781746 1.4142136 1.41421357-7.7781746 7.77817459 7.7781746 7.77817456L16.9705627 19l-7.7781745-7.7781746L1.41421356 19 0 17.5857864l7.7781746-7.77817456L0 2.02943725 1.41421356.61522369 9.1923882 8.39339828z" fill="currentColor" fill-rule="evenodd"></path>
    </svg></button>
                </div><button type="submit" class="search-bar__submit" aria-label="Pesquisar"><svg class="icon icon--search" viewBox="0 0 21 21" role="presentation">
      <g stroke-width="2" stroke="currentColor" fill="none" fill-rule="evenodd">
        <path d="M19 19l-5-5" stroke-linecap="square"></path>
        <circle cx="8.5" cy="8.5" r="7.5"></circle>
      </g>
    </svg><svg class="icon icon--search-loader" viewBox="0 0 64 64" role="presentation">
      <path opacity=".4" d="M23.8589104 1.05290547C40.92335108-3.43614731 58.45816642 6.79494359 62.94709453 23.8589104c4.48905278 17.06444068-5.74156424 34.59913135-22.80600493 39.08818413S5.54195825 57.2055303 1.05290547 40.1410896C-3.43602265 23.0771228 6.7944697 5.54195825 23.8589104 1.05290547zM38.6146353 57.1445143c13.8647142-3.64731754 22.17719655-17.89443541 18.529879-31.75914961-3.64743965-13.86517841-17.8944354-22.17719655-31.7591496-18.529879S3.20804604 24.7494569 6.8554857 38.6146353c3.64731753 13.8647142 17.8944354 22.17719655 31.7591496 18.529879z"></path>
      <path d="M1.05290547 40.1410896l5.80258022-1.5264543c3.64731754 13.8647142 17.89443541 22.17719655 31.75914961 18.529879l1.5264543 5.80258023C23.07664892 67.43614731 5.54195825 57.2055303 1.05290547 40.1410896z"></path>
    </svg></button>
              </div>

              <button type="button" class="search-bar__close-button hidden-tablet-and-up" style="justify-content: center; display: flex; flex-direction: row; align-items: center;" data-action="unfix-search">
                <span class="search-bar__close-text" style="padding-left: 10px;"><span class="icon-state__secondary"><svg class="icon icon--close" viewBox="0 0 19 19" role="presentation">
      <path d="M9.1923882 8.39339828l7.7781745-7.7781746 1.4142136 1.41421357-7.7781746 7.77817459 7.7781746 7.77817456L16.9705627 19l-7.7781745-7.7781746L1.41421356 19 0 17.5857864l7.7781746-7.77817456L0 2.02943725 1.41421356.61522369 9.1923882 8.39339828z" fill="currentColor" fill-rule="evenodd"></path>
    </svg></span></span>
              </button>
            </div>

            <div class="search-bar__inner">
              <div class="search-bar__inner-animation">
                <div class="search-bar__results" aria-hidden="true">
                  <div class="skeleton-container"><div class="search-bar__result-item search-bar__result-item--skeleton">
                        <div class="search-bar__image-container">
                          <div class="aspect-ratio aspect-ratio--square">
                            <div class="skeleton-image"></div>
                          </div>
                        </div>

                        <div class="search-bar__item-info">
                          <div class="skeleton-paragraph">
                            <div class="skeleton-text"></div>
                            <div class="skeleton-text"></div>
                          </div>
                        </div>
                      </div><div class="search-bar__result-item search-bar__result-item--skeleton">
                        <div class="search-bar__image-container">
                          <div class="aspect-ratio aspect-ratio--square">
                            <div class="skeleton-image"></div>
                          </div>
                        </div>

                        <div class="search-bar__item-info">
                          <div class="skeleton-paragraph">
                            <div class="skeleton-text"></div>
                            <div class="skeleton-text"></div>
                          </div>
                        </div>
                      </div><div class="search-bar__result-item search-bar__result-item--skeleton">
                        <div class="search-bar__image-container">
                          <div class="aspect-ratio aspect-ratio--square">
                            <div class="skeleton-image"></div>
                          </div>
                        </div>

                        <div class="search-bar__item-info">
                          <div class="skeleton-paragraph">
                            <div class="skeleton-text"></div>
                            <div class="skeleton-text"></div>
                          </div>
                        </div>
                      </div></div>

                  <div class="search-bar__results-inner"></div>
                </div></div>
            </div>
          </form>
        </div><div class="header__action-list"><div class="header__action-item hidden-tablet-and-up">
              <a class="header__action-item-link" href="/" data-action="toggle-search" aria-expanded="false" aria-label="Abrir busca"><svg class="icon icon--search" viewBox="0 0 21 21" role="presentation">
      <g stroke-width="2" stroke="currentColor" fill="none" fill-rule="evenodd">
        <path d="M19 19l-5-5" stroke-linecap="square"></path>
        <circle cx="8.5" cy="8.5" r="7.5"></circle>
      </g>
    </svg></a>
            </div><!-- INICIO RASTREAR -->
          
          <div class="header__action-item" style="position: relative; height: 23px;">
            <a class="header__action-item-link header__cart-toggle" href="rastrear.php">
              <div class="header__action-item-content" style="display: inline-flex">
                <div class="header-delivery-icon icon-state">
                  <span class="icon-state__primary"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 32 38" width="32" fill="var(--header-text-color)" style="margin-right: -8px;"><path d="M19,5H17V4a3,3,0,0,0-3-3H3A3,3,0,0,0,0,4V19H2.041A3.465,3.465,0,0,0,2,19.5a3.5,3.5,0,0,0,7,0,3.465,3.465,0,0,0-.041-.5h6.082a3.465,3.465,0,0,0-.041.5,3.5,3.5,0,0,0,7,0,3.465,3.465,0,0,0-.041-.5H24V10A5.006,5.006,0,0,0,19,5Zm0,2a3,3,0,0,1,3,3v1H17V7ZM7,19.5a1.5,1.5,0,0,1-3,0,1.418,1.418,0,0,1,.093-.5H6.907A1.418,1.418,0,0,1,7,19.5ZM15,17H2V4A1,1,0,0,1,3,3H14a1,1,0,0,1,1,1Zm5,2.5a1.5,1.5,0,0,1-3,0,1.41,1.41,0,0,1,.093-.5h2.814A1.41,1.41,0,0,1,20,19.5ZM17,17V13h5v4Z"/></svg></span>
                  <style>
                    .temadropmeta {
                      padding-right: 15px;
                      margin-top: -3px;
                    }
                    
                    @media screen and (max-width: 1280px) {
                    .temadropmeta {
                     height: 24px;
                     padding-right: 0px;
                     margin-top: 0px;
                    }

                    
               }
                    
                  </style>
                </div>
                <span class="hidden-pocket hidden-lap" style="line-height: 1.3; margin-left: 12px;">Rastrear Pedido</span>
              </div>
            </a>
          </div>
          
          <!-- FINAL RASTREAR -->
          
          <div class="header__action-item header__action-item--cart">
            <a class="header__action-item-link header__cart-toggle" href="carrinho.php"  data-no-instant>
              <div class="header__action-item-content">
                <div class="header__cart-icon icon-state" aria-expanded="false">
                  <span class="icon-state__primary">
                    
                   <svg xmlns="http://www.w3.org/2000/svg" style="margin-top: 10px;" id="Outline" viewBox="0 0 36 24" width="37" fill="var(--header-text-color)"><path d="M22.713,4.077A2.993,2.993,0,0,0,20.41,3H4.242L4.2,2.649A3,3,0,0,0,1.222,0H1A1,1,0,0,0,1,2h.222a1,1,0,0,1,.993.883l1.376,11.7A5,5,0,0,0,8.557,19H19a1,1,0,0,0,0-2H8.557a3,3,0,0,1-2.82-2h11.92a5,5,0,0,0,4.921-4.113l.785-4.354A2.994,2.994,0,0,0,22.713,4.077ZM21.4,6.178l-.786,4.354A3,3,0,0,1,17.657,13H5.419L4.478,5H20.41A1,1,0,0,1,21.4,6.178Z"/><circle cx="7" cy="22" r="2"/><circle cx="17" cy="22" r="2"/></svg>

                    
                    <span class="header__cart-count">1</span>
                  </span>

                  <span class="icon-state__secondary"><svg class="icon icon--close" viewBox="0 0 19 19" role="presentation">
      <path d="M9.1923882 8.39339828l7.7781745-7.7781746 1.4142136 1.41421357-7.7781746 7.77817459 7.7781746 7.77817456L16.9705627 19l-7.7781745-7.7781746L1.41421356 19 0 17.5857864l7.7781746-7.77817456L0 2.02943725 1.41421356.61522369 9.1923882 8.39339828z" fill="currentColor" fill-rule="evenodd"></path>
    </svg></span>
                </div>

                <span class="hidden-pocket hidden-lap">Carrinho</span>
              </div>
            </a></div>
        </div>
      </div>
    </div>
  </header><nav class="nav-bar">
     <div class="nav-bar__inner" style="text-align: center; color: var(--header-text-color);">
       <div class="container">
         <ul class="nav-bar__linklist list--unstyled" data-type="menu" style="background: #; border-radius: 10px 10px 0px 0;">
           <i class="fa fa-bars" style="margin-right: 10px; color: var(--header-text-color);" aria-hidden="true"></i><li class="nav-bar__item"><a href="/" class="nav-bar__link link" data-type="menuitem">Início</a></li><li class="nav-bar__item"><a href="produtos.php" class="nav-bar__link link" data-type="menuitem">Catálogo</a></li><li class="nav-bar__item"><a href="contato.php" class="nav-bar__link link" data-type="menuitem">Entrar em contato</a></li></ul>
        </div>
      </div>
    </nav></section><style>
    
    .img-topbar {
      justify-content: center!important;
    }
    
    .topbar-flex {
      display: flex!important;
    }
    
    .img-responsive-mob {
      width: 90%;
      height: auto;
    }
      
    .img-responsive-pc {
      width: 65%;
      height: auto;
    }

    @media screen and (max-width: 640px) {
    .imgdopc {
      display: none;
    }
    }
    
    @media screen and (min-width: 641px){
    .imgdomob {
      display: none;
    }
    }
    
  </style><div class="container-fluid color-line" style="
    background: linear-gradient(to right, #000000, #000000);
    height: 6px;
    width: 100%;">
      </div><style>
  :root {
    --header-is-sticky: 0;
    --header-inline-navigation: 1;
  }

  #shopify-section-header {
    position: relative;
    z-index: 5;}.header__logo-image {
      max-width: 155px !important;
    }

    @media screen and (min-width: 641px) {
      .header__logo-image {
        max-width: 225px !important;
      }
    }@media screen and (min-width: 1000px) {
      .search-bar.is-expanded .search-bar__top {
        box-shadow: 0 -1px #464646 inset;
      }
    }</style>

<script>
  document.documentElement.style.setProperty('--header-height', document.getElementById('shopify-section-header').clientHeight + 'px');
</script>

</div>
    <main id="main" role="main">
      <!-- BEGIN content_for_index --><div id="shopify-section-slideshow" class="shopify-section"><section data-section-id="slideshow" data-section-type="slideshow" data-section-settings='{
  "autoPlay": true,
  "prevNextButtons": false,
  "pageDots": false,
  "setGallerySize": true,
  "adaptiveHeight": true,
  "transitionEffect": "slide",
  "cycleSpeed": 5000
}'><link rel="preload" href="" imagesrcset="https://i.imgur.com/QU8lLC6.png" as="image" media="(max-width: 640px)">
    <link rel="preload" href="" imagesrcset="https://i.imgur.com/QU8lLC6.png" as="image" media="(min-width: 641px)"><div class="container container--flush">
    <div class="slideshow slideshow--preserve-ratio " style="color: #ffffff"><div class="slideshow__slide  is-selected" id="block-fa2eac7c-9fbf-4ea9-a172-eca738a9012d" data-block-index="0" ><div class="slideshow__slide-inner slideshow__slide-inner--middle-center lazyload image--fade-in" ><div class="aspect-ratio hidden-phone" style="padding-bottom: 33.333333333333336%">
                <img class="slideshow__image lazyload image--fade-in" alt="" data-src="https://i.imgur.com/QU8lLC6.png" data-widths="[800,900,1000,1100,1200,1300,1400,1600,1800]" data-sizes="auto">

                <noscript>
                  <img src=https://i.imgur.com/TcThzJc.png" alt="">
                </noscript>
              </div><div class="aspect-ratio hidden-tablet-and-up" style="padding-bottom: 146.66666666666666%">
                  <img class="slideshow__image lazyload image--fade-in" alt="" data-src="https://i.imgur.com/TcThzJc.png" data-widths="[600,700]" data-sizes="auto">

                  <noscript>
                    <img src="https://i.imgur.com/TcThzJc.png" alt="">
                  </noscript>
                </div></div>

          <style>
            #block-fa2eac7c-9fbf-4ea9-a172-eca738a9012d {
              color: #ffffff;
            }

            #block-fa2eac7c-9fbf-4ea9-a172-eca738a9012d .button {
              color: #000000;
              background: #ffffff;
            }

            #block-fa2eac7c-9fbf-4ea9-a172-eca738a9012d .button:hover {
              background: rgba(255, 255, 255, 0.8);
            }</style></div></div>
  </div>
</section>

</div><div id="shopify-section-16153541158fc73818" class="shopify-section"><section class="section" data-section-id="16153541158fc73818" data-section-type="featured-collection" data-section-settings='{
  "stackable": false,
  "layout": "vertical"
}'><div class="container">
    <header class="section__header">
      <div class="section__header-stack">
        <h2 class="section__title heading h3">Produtos + vendidos</h2>
      </div><a href="/collections/frontpage" class="section__action-link link">Ver Todos <svg class="icon icon--tail-right" viewBox="0 0 24 24" role="presentation">
      <path fill="currentColor" d="M22.707 11.293L15 3.586 13.586 5l6 6H2c-.553 0-1 .448-1 1s.447 1 1 1h17.586l-6 6L15 20.414l7.707-7.707c.391-.391.391-1.023 0-1.414z"></path>
    </svg></a></header>
  </div>

  <div class="container "><div class="scroller">
        <div class="scroller__inner">
          <div class="product-list product-list--vertical product-list--scrollable ">
            <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        29%</span></div><a href='produto.php?id=119' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://blackskullusa.vtexassets.com/arquivos/ids/155569-1600-auto?v=1762098195&width=1600&height=auto&aspect=true' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://blackskullusa.vtexassets.com/arquivos/ids/155569-1600-auto?v=1762098195&width=1600&height=auto&aspect=true' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://blackskullusa.vtexassets.com/arquivos/ids/155569-1600-auto?v=1762098195&width=1600&height=auto&aspect=true' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=119' class='product-item__title text--strong link'>CREATINE TURBO - 300G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 69,90</span>
              <span class='price price--compare'>R$ 89,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 5,75 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        100%</span></div><a href='produto.php?id=118' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/8H0xjzy.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/8H0xjzy.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/8H0xjzy.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=118' class='product-item__title text--strong link'>TERMOGÊNICO THERMO FLAME - 120 TABLETES</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 39,90</span>
              <span class='price price--compare'>R$ 79,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 3,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        30%</span></div><a href='produto.php?id=117' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/cRsldXs.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/cRsldXs.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/cRsldXs.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=117' class='product-item__title text--strong link'>FAT BURNER</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 99,90</span>
              <span class='price price--compare'>R$ 129,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 8,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        27%</span></div><a href='produto.php?id=116' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/hoLebLA.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/hoLebLA.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/hoLebLA.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=116' class='product-item__title text--strong link'>CARNITINE 60 CÁPSULAS</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 78,90</span>
              <span class='price price--compare'>R$ 99,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 6,50 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        167%</span></div><a href='produto.php?id=115' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/IMnN6Zk.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/IMnN6Zk.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/IMnN6Zk.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=115' class='product-item__title text--strong link'>TERMOGÊNICO THERMO FLAME - 60 TABLETES</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 29,90</span>
              <span class='price price--compare'>R$ 79,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 2,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        77%</span></div><a href='produto.php?id=114' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/LSeYexB.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/LSeYexB.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/LSeYexB.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=114' class='product-item__title text--strong link'>L-CARNITINA 60 CAPS </a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 59,90</span>
              <span class='price price--compare'>R$ 105,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,92 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        80%</span></div><a href='produto.php?id=113' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/pnOdeza.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/pnOdeza.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/pnOdeza.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=113' class='product-item__title text--strong link'>PRÉ TREINO B.O.P.E 150G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 49,90</span>
              <span class='price price--compare'>R$ 89,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,08 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        33%</span></div><a href='produto.php?id=112' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/baIT5jd.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/baIT5jd.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/baIT5jd.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=112' class='product-item__title text--strong link'>BONE CRUSHER CAFFEINE FREE 300G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 149,90</span>
              <span class='price price--compare'>R$ 199,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 12,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        31%</span></div><a href='produto.php?id=111' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/UixXjZq.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/UixXjZq.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/UixXjZq.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=111' class='product-item__title text--strong link'>PRÉ TREINO SCALP - 300G </a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 129,90</span>
              <span class='price price--compare'>R$ 169,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 10,75 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        50%</span></div><a href='produto.php?id=110' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/R4vOgss.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/R4vOgss.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/R4vOgss.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=110' class='product-item__title text--strong link'>PRÉ TREINO CROSSBONES - 150G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 59,90</span>
              <span class='price price--compare'>R$ 89,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,92 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        70%</span></div><a href='produto.php?id=109' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/kdBonje.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/kdBonje.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/kdBonje.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=109' class='product-item__title text--strong link'>NOVO BONE CRUSHER NITRO 2T - PRÉ-TREINO 300G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 99,90</span>
              <span class='price price--compare'>R$ 169,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 8,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        72%</span></div><a href='produto.php?id=108' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/lM6rEul.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/lM6rEul.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/lM6rEul.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=108' class='product-item__title text--strong link'>PRÉ TREINO SCALP - 150G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 69,90</span>
              <span class='price price--compare'>R$ 119,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 5,75 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        60%</span></div><a href='produto.php?id=107' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/mEKiKxy.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/mEKiKxy.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/mEKiKxy.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=107' class='product-item__title text--strong link'>HIPERCALÓRICO MASSTODON - 3KG - REFIL</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 99,90</span>
              <span class='price price--compare'>R$  159,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 8,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        11%</span></div><a href='produto.php?id=106' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/5JlHF0Q.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/5JlHF0Q.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/5JlHF0Q.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=106' class='product-item__title text--strong link'>HIPERCALÓRICO MONSTROUS - 6LB - 2,7KG</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 269,90</span>
              <span class='price price--compare'>R$  299,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 22,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        67%</span></div><a href='produto.php?id=105' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/Ix0WAS9.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/Ix0WAS9.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/Ix0WAS9.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=105' class='product-item__title text--strong link'>MASS GAINER TURBO REFIL - 1,6KG</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 59,90</span>
              <span class='price price--compare'>R$ 99,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,92 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        23%</span></div><a href='produto.php?id=104' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/5q8gRcP.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/5q8gRcP.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/5q8gRcP.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=104' class='product-item__title text--strong link'>HIPERCALÓRICO MASS GAINER - 1,5KG</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 89,90</span>
              <span class='price price--compare'>R$ 110,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 7,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        36%</span></div><a href='produto.php?id=103' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/Xcz12MT.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/Xcz12MT.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/Xcz12MT.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=103' class='product-item__title text--strong link'>HIPERCALÓRICO MASSTODON - 3KG</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 109,90</span>
              <span class='price price--compare'>R$ 149,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 9,08 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        50%</span></div><a href='produto.php?id=102' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/MEiZ5uF.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/MEiZ5uF.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/MEiZ5uF.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=102' class='product-item__title text--strong link'>PALATINOSE - 300G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 59,90</span>
              <span class='price price--compare'>R$ 89,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,92 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        100%</span></div><a href='produto.php?id=101' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/YD6HykD.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/YD6HykD.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/YD6HykD.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=101' class='product-item__title text--strong link'>DEXTROSE TURBO REFIL - 1KG</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 39,90</span>
              <span class='price price--compare'>R$ 79,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 3,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        100%</span></div><a href='produto.php?id=100' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/nDA1XkX.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/nDA1XkX.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/nDA1XkX.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=100' class='product-item__title text--strong link'>MALTODEXTRIN TURBO REFIL - 1KG</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 29,90</span>
              <span class='price price--compare'>R$ 59,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 2,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        46%</span></div><a href='produto.php?id=99' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/99nM0Uh.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/99nM0Uh.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/99nM0Uh.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=99' class='product-item__title text--strong link'>BARRA DE PROTEÍNA GOURMET C/ COLOSTRO - DISPLAY C/ 12 </a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 129,90</span>
              <span class='price price--compare'>R$ 189,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 10,75 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        10%</span></div><a href='produto.php?id=98' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/nrqHWkP.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/nrqHWkP.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/nrqHWkP.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=98' class='product-item__title text--strong link'>HYDROLYSIS - 907G (WHEY PROTEIN ISOLADO HIDROLISADO)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 209,90</span>
              <span class='price price--compare'>R$ 229,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 17,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        27%</span></div><a href='produto.php?id=97' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/SsULAHi.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/SsULAHi.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/SsULAHi.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=97' class='product-item__title text--strong link'>WHEY TURBO REFIL - 907G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$  59,90</span>
              <span class='price price--compare'>R$ 75,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,92 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        5%</span></div><a href='produto.php?id=96' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/iTgSick.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/iTgSick.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/iTgSick.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=96' class='product-item__title text--strong link'>WHEY ZERO BLACK SKULL REFIL - 837G (WHEY PROTEIN ISOLADO)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 249,90</span>
              <span class='price price--compare'>R$ 263,00</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 20,75 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        6%</span></div><a href='produto.php?id=95' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/ZflCUYV.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/ZflCUYV.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/ZflCUYV.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=95' class='product-item__title text--strong link'>WHEY ZERO (COM LACTASE) BLACK SKULL - 900G </a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 299,90</span>
              <span class='price price--compare'>R$ 319,00</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 24,92 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        13%</span></div><a href='produto.php?id=94' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/clBRdwd.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/clBRdwd.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/clBRdwd.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=94' class='product-item__title text--strong link'>WHEY 3HD GOURMET BLACK SKULL REFIL - 900G (WPC, WPI E WPH)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 149,90</span>
              <span class='price price--compare'>R$ 169,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 12,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        20%</span></div><a href='produto.php?id=93' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/ykPkivC.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/ykPkivC.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/ykPkivC.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=93' class='product-item__title text--strong link'>PROTEIN MUSCLE BLACK SKULL REFIL - 900G (BLEND PROTEÍNAS)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 99,90</span>
              <span class='price price--compare'>R$ 119,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 8,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        30%</span></div><a href='produto.php?id=92' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/169Xl5M.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/169Xl5M.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/169Xl5M.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=92' class='product-item__title text--strong link'>PROTEÍNA VEGANA GREEN MAN - 400G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 169,90</span>
              <span class='price price--compare'>R$ 220,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 14,08 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        40%</span></div><a href='produto.php?id=91' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/42iwQFd.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/42iwQFd.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/42iwQFd.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=91' class='product-item__title text--strong link'>ALBUMIN TURBO REFIL (ALBUMINA) - 500G</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 49,90</span>
              <span class='price price--compare'>R$ 69,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 4,08 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        19%</span></div><a href='produto.php?id=90' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/gsaNC4E.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/gsaNC4E.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/gsaNC4E.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=90' class='product-item__title text--strong link'>WHEY 3HD GOURMET BLACK SKULL - 900G (WPC, WPI E WPH)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 159,90</span>
              <span class='price price--compare'>R$ 189,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 13,25 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        0%</span></div><a href='produto.php?id=89' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/5QKK0nC.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/5QKK0nC.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/5QKK0nC.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=89' class='product-item__title text--strong link'>COMBO PRÉ-TREINO BONE CRUSHER NITRO 2T BLACK SKULL</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ </span>
              <span class='price price--compare'>R$ </span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 0,00 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        23%</span></div><a href='produto.php?id=88' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/sMxmI7G.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/sMxmI7G.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/sMxmI7G.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=88' class='product-item__title text--strong link'>COMBO PRÉ-TREINO BOPE C/ 3 UNID</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 129,90</span>
              <span class='price price--compare'>R$ 159,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 10,75 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        43%</span></div><a href='produto.php?id=87' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/EXCi5U4.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/EXCi5U4.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/EXCi5U4.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=87' class='product-item__title text--strong link'>KIT TRIPLE JOINT E JOINT FLEX</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 94,90</span>
              <span class='price price--compare'>R$ 135,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 7,83 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        24%</span></div><a href='produto.php?id=80' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://imgur.com/i68E5Lh.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/i68E5Lh.png' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://imgur.com/i68E5Lh.png' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=80' class='product-item__title text--strong link'>KIT CREATINE TURBO (POTE + REFIL)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 209,90</span>
              <span class='price price--compare'>R$ 259,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 17,42 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>  <div class='product-item product-item--vertical  1/4--lap 1/5--desk 1/6--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        114%</span></div><a href='produto.php?id=79' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 98.03921568627452%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663189823741' data-src='https://cdn.shopify.com/s/files/1/0707/0973/9838/products/01_22f9855a-a623-4d3b-bd15-0142a75ee058_1600x.png?v=1673976253' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><img class='product-item__secondary-image lazyload image--fade-in' data-src='https://cdn.shopify.com/s/files/1/0707/0973/9838/products/01_22f9855a-a623-4d3b-bd15-0142a75ee058_1600x.png?v=1673976253' data-sizes='auto' data-widths='[200,300,400,500,600,700,800]' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'><noscript>
          <img src='https://cdn.shopify.com/s/files/1/0707/0973/9838/products/01_22f9855a-a623-4d3b-bd15-0142a75ee058_1600x.png?v=1673976253' alt='Fogão 4 Bocas Electrolux Automático com Grill e Tripla Chama (PRATA)'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=79' class='product-item__title text--strong link'>COMBO WHEY 2X + BCAA + CREATINA + COQUETELEIRA </a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 139,90</span>
              <span class='price price--compare'>R$ 299,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 11,58 </b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>
        
      </div><div>
      <!-- Start Areviews Collection Rating Code -->
      <div class='areviews_product_item areviews_stars7898303365373'  data-product-id='7898303365373'></div>
      
      <!-- End Areviews Collection Rating Code --></div></div></div>
  </div>
        </div>
        </div>
      </div></div><div id="modal-quick-view-16153541158fc73818" class="modal" aria-hidden="true">
    <div class="modal__dialog modal__dialog--stretch" role="dialog">
      <button class="modal__close link" data-action="close-modal"><svg class="icon icon--close" viewBox="0 0 19 19" role="presentation">
      <path d="M9.1923882 8.39339828l7.7781745-7.7781746 1.4142136 1.41421357-7.7781746 7.77817459 7.7781746 7.77817456L16.9705627 19l-7.7781745-7.7781746L1.41421356 19 0 17.5857864l7.7781746-7.77817456L0 2.02943725 1.41421356.61522369 9.1923882 8.39339828z" fill="currentColor" fill-rule="evenodd"></path>
    </svg></button>

      <div class="modal__loader"><svg class="icon icon--search-loader" viewBox="0 0 64 64" role="presentation">
      <path opacity=".4" d="M23.8589104 1.05290547C40.92335108-3.43614731 58.45816642 6.79494359 62.94709453 23.8589104c4.48905278 17.06444068-5.74156424 34.59913135-22.80600493 39.08818413S5.54195825 57.2055303 1.05290547 40.1410896C-3.43602265 23.0771228 6.7944697 5.54195825 23.8589104 1.05290547zM38.6146353 57.1445143c13.8647142-3.64731754 22.17719655-17.89443541 18.529879-31.75914961-3.64743965-13.86517841-17.8944354-22.17719655-31.7591496-18.529879S3.20804604 24.7494569 6.8554857 38.6146353c3.64731753 13.8647142 17.8944354 22.17719655 31.7591496 18.529879z"></path>
      <path d="M1.05290547 40.1410896l5.80258022-1.5264543c3.64731754 13.8647142 17.89443541 22.17719655 31.75914961 18.529879l1.5264543 5.80258023C23.07664892 67.43614731 5.54195825 57.2055303 1.05290547 40.1410896z"></path>
    </svg></div>

      <div class="modal__inner"></div>
    </div>
  </div>
</section>

</div><div id="shopify-section-16494890143053ae61" class="shopify-section"><section class="section" data-section-id="16494890143053ae61" data-section-type="image-with-text">
  <div class="container"><div class="image-with-text"><div class="image-with-text__image-container" style="width: 55%;"><div class="aspect-ratio" style="padding-bottom: 66.66666666666667%"><img class="lazyload image--fade-in" data-src="https://cdn.shopify.com/s/files/1/0707/0973/9838/files/luego_600x.png?v=1673911110" data-widths="[300,400,500,600,700,800,900,1000,1100,1200]" data-sizes="auto" alt="">

            <noscript>
              <img src="https://cdn.shopify.com/s/files/1/0707/0973/9838/files/luego_600x.png?v=1673911110" alt="">
            </noscript>
          </div></div>
        <div class="image-with-text__text-container">
        <div class="image-with-text__text-aligner"><h2 style="font-size: 32px;margin-bottom: 5px;font-weight: bold;">Quem Somos?</h2><div class="rte">
            <p>       A Black Skull USA é uma marca de suplementos alimentares com foco em atletas de alta performance. Nossa sede no Brasil está alocada em Embu das Artes – SP, com mais de 12.000 m² de área construída, com alta capacidade produtiva. Nossos produtos trabalham com as melhores matérias-primas do mercado e tem como principal característica maior concentração de insumos, que proporcionam níveis de pureza mais altos e por consequência otimizam a qualidade de nossos produtos.</p>
</div>
        </div>
      </div>
</div>
  </div>
</section>

</div><div id="shopify-section-1649913264519d35a7" class="shopify-section"><section class="section" data-section-id="1649913264519d35a7" data-section-type="featured-collection" data-section-settings='{
  "stackable": false,
  "layout": "vertical"
}'>
  <div class="container container--flush"><div class="featured-collection lazyload" >
      <header class="featured-collection__header lazyload" ><h2 class="featured-collection__title heading h2">Mais vendidos de sua coleção</h2><p class="featured-collection__text">Veja mais produtos relacionados clicando no botão abaixo</p><a href="" class="featured-collection__cta button button--floating">Ver mais produtos</a></header>

      <div class="featured-collection__content">
        <div class="scroller scroller--flush">
          <div class="scroller__inner">
            <div class="product-list product-list--scrollable">
              
            
            
            <div class='product-item product-item--vertical  1/2--lap 1/3--desk 1/4--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        114%</span></div><a href='produto.php?id=79' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 87.62886597938144%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663182254333' data-src='https://cdn.shopify.com/s/files/1/0707/0973/9838/products/01_22f9855a-a623-4d3b-bd15-0142a75ee058_1600x.png?v=1673976253' data-sizes='auto' data-widths='[200,300,400]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        <img class='product-item__secondary-image lazyload image--fade-in' data-src='https://cdn.shopify.com/s/files/1/0707/0973/9838/products/01_22f9855a-a623-4d3b-bd15-0142a75ee058_1600x.png?v=1673976253' data-sizes='auto' data-widths='[200,300,400,500]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'><noscript>
          <img src='https://cdn.shopify.com/s/files/1/0707/0973/9838/products/01_22f9855a-a623-4d3b-bd15-0142a75ee058_1600x.png?v=1673976253' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=79' class='product-item__title text--strong link'>COMBO WHEY 2X + BCAA + CREATINA + COQUETELEIRA </a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 139,90</span>
              <span class='price price--compare'>R$ 299,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 11,58</b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>                   
        </div></div>
                  </div>
                </div>
       <div class='product-item product-item--vertical  1/2--lap 1/3--desk 1/4--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        24%</span></div><a href='produto.php?id=80' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 87.62886597938144%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663182254333' data-src='https://imgur.com/i68E5Lh.png' data-sizes='auto' data-widths='[200,300,400]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        <img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/i68E5Lh.png' data-sizes='auto' data-widths='[200,300,400,500]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'><noscript>
          <img src='https://imgur.com/i68E5Lh.png' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=80' class='product-item__title text--strong link'>KIT CREATINE TURBO (POTE + REFIL)</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 209,90</span>
              <span class='price price--compare'>R$ 259,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 17,42</b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>                   
        </div></div>
                  </div>
                </div>
       <div class='product-item product-item--vertical  1/2--lap 1/3--desk 1/4--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        43%</span></div><a href='produto.php?id=87' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 87.62886597938144%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663182254333' data-src='https://imgur.com/EXCi5U4.png' data-sizes='auto' data-widths='[200,300,400]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        <img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/EXCi5U4.png' data-sizes='auto' data-widths='[200,300,400,500]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'><noscript>
          <img src='https://imgur.com/EXCi5U4.png' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=87' class='product-item__title text--strong link'>KIT TRIPLE JOINT E JOINT FLEX</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 94,90</span>
              <span class='price price--compare'>R$ 135,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 7,83</b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>                   
        </div></div>
                  </div>
                </div>
       <div class='product-item product-item--vertical  1/2--lap 1/3--desk 1/4--wide'><div class='product-item__label-list'><span class='product-label product-label--on-sale'>
        
  <svg xmlns='http://www.w3.org/2000/svg' class='icon icon-tabler icon-tabler-arrow-down' width='1.3em' height='1.3em' viewBox='0 0 24 24' stroke-width='2.5' stroke='currentColor' fill='none' stroke-linecap='round' stroke-linejoin='round' style='margin-right: -3px; margin-left: -3px;'>
  <path stroke='none' d='M0 0h24v24H0z' fill='none'></path>
  <line x1='12' y1='5' x2='12' y2='19'></line>
  <line x1='18' y1='13' x2='12' y2='19'></line>
  <line x1='6' y1='13' x2='12' y2='19'></line>
  </svg>
        
        23%</span></div><a href='produto.php?id=88' class='product-item__image-wrapper product-item__image-wrapper--with-secondary'><div class='aspect-ratio aspect-ratio--square' style='padding-bottom: 87.62886597938144%'>
        <img class='product-item__primary-image lazyload image--fade-in' data-media-id='30663182254333' data-src='https://imgur.com/sMxmI7G.png' data-sizes='auto' data-widths='[200,300,400]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        <img class='product-item__secondary-image lazyload image--fade-in' data-src='https://imgur.com/sMxmI7G.png' data-sizes='auto' data-widths='[200,300,400,500]' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'><noscript>
          <img src='https://imgur.com/sMxmI7G.png' alt='Furadeira e Parafusadeira de impacto 1/2” 13mm Bivolt à bateria 20 Volts com 2 baterias DCD776C2 - Dewalt'>
        </noscript>
      </div>
    </a><div class='product-item__info'>
    <div class='product-item__info-inner'>
  <a href='produto.php?id=88' class='product-item__title text--strong link'>COMBO PRÉ-TREINO BOPE C/ 3 UNID</a><div class='product-item__price-list price-list'><span class='price price--highlight'>R$ 129,90</span>
              <span class='price price--compare'>R$ 159,90</span></div>
  <p style='color: #black; margin: -24px 0px 0px 0px; font-size: 14px;'>em até <b>12x</b> de <b style='color: var(--product-on-sale-accent)'>R$ 10,75</b></p><div style='width: 100%; margin-top: -5px;'>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
        <i style='color: var(--corstars); font-size: 12px;' class='fas fa-star' aria-hidden='true'></i>
  
        <span style='font-size: 12px; color: #bbbbbb'>(5.0)</span>                   
        </div></div>
                  </div>
                </div>
                   
</div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<style>
  #shopify-section-1649913264519d35a7 .featured-collection {
    background-image: linear-gradient(60deg, #000000, #000000);
  }

  #shopify-section-1649913264519d35a7 .featured-collection__header {
    color: #ffffff;
  }

  #shopify-section-1649913264519d35a7 .button {
    color: #702dfa;
    background-color: #ffffff;
  }
</style>

</div><!-- END content_for_index -->
    </main><div id="shopify-section-text-with-icons" class="shopify-section"><section class="section section--tight" data-section-id="text-with-icons" data-section-type="text-with-icons">
    <div class="container container--flush">
      <div class="text-with-icons "><div class="text-with-icons__item" data-block-index="0" >
            <div class="text-with-icons__icon-wrapper"><svg viewBox="0 0 24 24" role="presentation">
      <g transform="translate(1 1)" fill="none" fill-rule="evenodd">
        <circle fill="#737b97" fill-rule="nonzero" cx="6.5" cy="17.5" r="1.5"></circle>
        <path d="M13 16v4c0 1.1-.9 2-2 2H2c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h4" stroke="#737b97" stroke-width="1.5" stroke-linecap="square"></path>
        <path stroke="#333333" stroke-width="1.5" stroke-linecap="square" d="M22 12H6V0h16zM6 4h16M12 8h-2"></path>
      </g>
    </svg></div><div class="text-with-icons__content-wrapper"><p class="text-with-icons__title text--strong">Compra Segura</p><div class="text-with-icons__content rte">
                    <p>Ambiente  seguro para pagamentos online</p>
                  </div></div></div><div class="text-with-icons__item" data-block-index="1" >
            <div class="text-with-icons__icon-wrapper"><svg viewBox="0 0 24 22" role="presentation">
      <g transform="translate(1 1)" stroke-width="1.5" fill="none" fill-rule="evenodd">
        <path d="M5 10H2M5 15H4" stroke="#333333" stroke-linecap="square"></path>
        <path stroke="#737b97" d="M16.829 16H22v-6l-4-2-1-4H9v12h2.171"></path>
        <path d="M0 5h5" stroke="#333333" stroke-linecap="square"></path>
        <path stroke="#737b97" stroke-linecap="square" d="M0 0h9v4"></path>
        <circle stroke="#737b97" stroke-linecap="square" cx="14" cy="17" r="3"></circle>
        <path stroke="#737b97" stroke-linecap="square" d="M13 7v2h2"></path>
      </g>
    </svg></div><div class="text-with-icons__content-wrapper"><p class="text-with-icons__title text--strong">Frete Grátis</p><div class="text-with-icons__content rte">
                    <p>Envio rápido e acompanhado com código de rastreio<br/></p>
                  </div></div></div><div class="text-with-icons__item" data-block-index="2" >
            <div class="text-with-icons__icon-wrapper"><svg viewBox="0 0 24 22" role="presentation">
      <g stroke-width="1.5" fill="none" fill-rule="evenodd">
        <path stroke="#737b97" d="M5 6.1000004L1 9v12h22V9l-4-2.8999996M1 9l22 12M23 9l-11 6"></path>
        <path d="M13.8461533 1C13.0769224 1 12.3846149 1.3846154 12 2c-.3846159-.6153846-1.0769234-1-1.8461542-1C8.9230766 1 8 2 8 3.2307687c0 2.1538463 4 5.4615388 4 5.4615388s4-3.3076925 4-5.4615388C16 2 15.0769224 1 13.8461533 1z" stroke="#333333" stroke-linecap="square"></path>
      </g>
    </svg></div><div class="text-with-icons__content-wrapper"><p class="text-with-icons__title text--strong">Suporte Profissional</p><div class="text-with-icons__content rte">
                    <p>Equipe de suporte de extrema qualidade a semana toda<br/></p>
                  </div></div></div><div class="text-with-icons__item" data-block-index="3" >
            <div class="text-with-icons__icon-wrapper"><svg viewBox="0 0 23 24" role="presentation">
      <g transform="translate(1 1)" stroke-width="1.5" fill="none" fill-rule="evenodd">
        <path stroke="#333333" d="M8 4h8v7"></path>
        <path stroke="#333333" stroke-linecap="square" d="M11 7L8 4l3-3"></path>
        <circle stroke="#737b97" stroke-linecap="square" cx="6" cy="20" r="2"></circle>
        <circle stroke="#737b97" stroke-linecap="square" cx="18" cy="20" r="2"></circle>
        <path stroke="#737b97" stroke-linecap="square" d="M21 5l-2 10H5L3 0H0"></path>
      </g>
    </svg></div><div class="text-with-icons__content-wrapper"><p class="text-with-icons__title text--strong">Satisfação ou Reembolso</p><div class="text-with-icons__content rte">
                    <p>Caso haja algo, devolvemos seu dinheiro com velocidade</p>
                  </div></div></div></div>
    </div>
  </section></div>
    <div id="shopify-section-footer" class="shopify-section"> <div class="container-fluid color-line" style="
    background: linear-gradient(to right, #000000, #000000);
    height: 6px;
    width: 100%;">
      </div><footer class="footer" data-section-id="footer" data-section-type="footer" role="contentinfo">
  <div class="container">
    <div class="footer__wrapper"><div class="footer__block-list"><div class="footer__block-item footer__block-item--text" ><h1 class="header__logo logodorodape" style="margin-bottom: 24px;"><a href="/" class="header__logo-link"><img class="header__logo-image"
                   style="max-width: px"
                   width="801"
                   height="246"
                   src="//cdn.shopify.com/s/files/1/0707/0973/9838/files/logo_200x@2x.png?v=1673904283"
                   alt="OFICIAL BLACK SKULL BRASIL"></a></h1><button class="footer__title heading h6" disabled aria-expanded="false" aria-controls="block-c9a6c378-573f-4c54-9fc6-5ca6e279f3f2" data-action="toggle-collapsible">
                    <span>ATENDIMENTO AO CLIENTE</span>
                    <span class="plus-button"></span>
                  </button>

                  <div id="block-c9a6c378-573f-4c54-9fc6-5ca6e279f3f2" class="footer__collapsible">
                    <div class="footer__collapsible-content">
                      <div class="rte">
                        <p><strong>SAC (Serviço de Atendimento ao Consumidor)</strong></p><p><strong>E-mail: </strong>atendimento@lojablackskull.com<br/><strong>WhatsApp:</strong> +55 21959515865</p>
                      </div>
                    </div>
                  </div>
                </div><div class="footer__block-item footer__block-item--links" >                    
                    <button class="footer__title heading h6" disabled aria-expanded="true" aria-controls="block-footer-1" data-action="toggle-collapsible">
                      <span>Menu de rodapé</span>
                      <span class="plus-button"></span>
                    </button>

                    <div id="block-footer-1" class="footer__collapsible" style="height: auto;">
                      <div class="footer__collapsible-content">
                        <ul class="footer__linklist list--unstyled"><li>
                              <a href="/search" class="footer__link-item link">Pesquisar</a>
                            </li></ul>
                      </div>
                    </div>
                  </div><div class="footer__block-item footer__block-item--newsletter" >
                  <p class="footer__title heading h6">Nossa Newsletter</p>

                  <div class="footer__newsletter-wrapper"><div class="footer__newsletter-text rte"><p>Assine nossa newsletter e receba as melhores ofertas DE GRAÇA!</p></div><form method="post" action="/contact#footer-newsletter" id="footer-newsletter" accept-charset="UTF-8" class="footer__newsletter-form"><input type="hidden" name="form_type" value="customer" /><input type="hidden" name="utf8" value="✓" /><input type="hidden" name="contact[tags]" value="newsletter">

                        <div class="form__input-wrapper form__input-wrapper--labelled">
                          <input type="email" id="footer[contact][email]" name="contact[email]" class="form__field form__field--text" required="">
                          <label for="footer[contact][email]" class="form__floating-label">Seu e-mail</label>
                        </div>

                        <button type="submit" class="form__submit form__submit--tight button button--primary">Enviar</button></form></div>
                </div></div><aside class="footer__aside"><center style="margin-top: 20px;"><p style="font-size: 10pt;"></b></p></center><div class="footer__aside-item footer__aside-item--payment">
            <p class="footer__aside-title">Nós aceitamos</p>

            <div class="payment-list">
               <svg class="payment-list__item" xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 38 24" width="38" height="24" aria-labelledby="pi-american_express"><title id="pi-american_express">American Express</title><g fill="none"><path fill="#000" d="M35,0 L3,0 C1.3,0 0,1.3 0,3 L0,21 C0,22.7 1.4,24 3,24 L35,24 C36.7,24 38,22.7 38,21 L38,3 C38,1.3 36.6,0 35,0 Z" opacity=".07"></path><path fill="#006FCF" d="M35,1 C36.1,1 37,1.9 37,3 L37,21 C37,22.1 36.1,23 35,23 L3,23 C1.9,23 1,22.1 1,21 L1,3 C1,1.9 1.9,1 3,1 L35,1"></path><path fill="#FFF" d="M8.971,10.268 L9.745,12.144 L8.203,12.144 L8.971,10.268 Z M25.046,10.346 L22.069,10.346 L22.069,11.173 L24.998,11.173 L24.998,12.412 L22.075,12.412 L22.075,13.334 L25.052,13.334 L25.052,14.073 L27.129,11.828 L25.052,9.488 L25.046,10.346 L25.046,10.346 Z M10.983,8.006 L14.978,8.006 L15.865,9.941 L16.687,8 L27.057,8 L28.135,9.19 L29.25,8 L34.013,8 L30.494,11.852 L33.977,15.68 L29.143,15.68 L28.065,14.49 L26.94,15.68 L10.03,15.68 L9.536,14.49 L8.406,14.49 L7.911,15.68 L4,15.68 L7.286,8 L10.716,8 L10.983,8.006 Z M19.646,9.084 L17.407,9.084 L15.907,12.62 L14.282,9.084 L12.06,9.084 L12.06,13.894 L10,9.084 L8.007,9.084 L5.625,14.596 L7.18,14.596 L7.674,13.406 L10.27,13.406 L10.764,14.596 L13.484,14.596 L13.484,10.661 L15.235,14.602 L16.425,14.602 L18.165,10.673 L18.165,14.603 L19.623,14.603 L19.647,9.083 L19.646,9.084 Z M28.986,11.852 L31.517,9.084 L29.695,9.084 L28.094,10.81 L26.546,9.084 L20.652,9.084 L20.652,14.602 L26.462,14.602 L28.076,12.864 L29.624,14.602 L31.499,14.602 L28.987,11.852 L28.986,11.852 Z"></path></g></svg>

              
                <svg class="payment-list__item" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-boleto"><title id="pi-boleto">Boleto</title><path fill="#fff" d="M35.7 23.965H2.3a2.307 2.307 0 0 1-2.3-2.3v-19.4C0 1 1.035-.035 2.3-.035h33.4c1.265 0 2.3 1.035 2.3 2.3v19.4c0 1.265-1.035 2.3-2.3 2.3z"></path><path fill="#A7A8AB" d="M35.564 23.965H2.436c-1.344 0-2.436-1.077-2.436-2.4v-19.2c0-1.323 1.092-2.4 2.436-2.4h33.128c1.344 0 2.436 1.077 2.436 2.4v19.2c0 1.323-1.092 2.4-2.436 2.4zM2.436.925c-.806 0-1.462.646-1.462 1.44v19.2c0 .794.656 1.44 1.462 1.44h33.128c.806 0 1.462-.646 1.462-1.44v-19.2c0-.794-.656-1.44-1.462-1.44H2.436z" opacity=".25"></path><path d="M8.079 4.945h.7v6.298h-.7zm-1.83 0h.7v6.298h-.7zm7.256 0h1.901v6.298h-1.901zm9.715 0h.95v6.298h-.95zm2.324 0h.95v6.298h-.95zm3.804 0h1.221v6.298h-1.221zm-1.375 0h.395v6.298h-.395zm-6.389 0h.395v6.298h-.395zm-.845 0h.395v6.298h-.395zm-2.746 0h.395v6.298h-.395zm-6.31 0h.395v6.298h-.395zm-1.163 0h.733v6.298h-.733zM6.249 19.3v-6.478H8.68c.495 0 .891.065 1.191.196.299.131.532.333.701.606.17.271.255.556.255.855 0 .276-.075.537-.225.781a1.604 1.604 0 0 1-.679.593c.392.115.694.311.903.588.211.276.317.603.317.98 0 .305-.065.587-.193.847a1.644 1.644 0 0 1-.475.603c-.189.14-.425.247-.709.32a4.328 4.328 0 0 1-1.046.109H6.248zm.86-3.755H8.51c.38 0 .653-.026.817-.075a.903.903 0 0 0 .493-.324.936.936 0 0 0 .166-.567 1.03 1.03 0 0 0-.155-.568c-.103-.164-.25-.278-.442-.338s-.52-.09-.985-.09H7.109v1.963zm0 2.995h1.614c.277 0 .472-.011.585-.032.196-.035.362-.094.495-.176a.946.946 0 0 0 .327-.362c.086-.158.128-.341.128-.547 0-.243-.062-.452-.187-.632a.978.978 0 0 0-.516-.377c-.219-.072-.535-.109-.947-.109H7.109v2.235zm4.813-1.588c0-.867.241-1.509.725-1.927.403-.347.896-.52 1.476-.52.644 0 1.172.211 1.582.633.409.421.614 1.004.614 1.748 0 .603-.09 1.077-.271 1.422a1.92 1.92 0 0 1-.792.805 2.292 2.292 0 0 1-1.132.286c-.657 0-1.188-.21-1.594-.63-.406-.421-.608-1.027-.608-1.817zm.814.002c0 .6.131 1.05.394 1.347.264.299.594.448.994.448.395 0 .724-.149.988-.449.262-.3.394-.757.394-1.371 0-.579-.133-1.018-.397-1.315a1.261 1.261 0 0 0-.985-.448c-.4 0-.73.148-.994.445-.262.297-.394.745-.394 1.344zm4.498 2.346v-6.478h.796V19.3h-.796zm5.231-1.52l.823.109c-.128.478-.368.85-.718 1.114-.35.264-.796.397-1.341.397-.685 0-1.227-.211-1.629-.633-.401-.421-.602-1.013-.602-1.775 0-.787.202-1.399.608-1.834.406-.436.932-.653 1.579-.653.626 0 1.137.213 1.534.639.397.427.596 1.027.596 1.8l-.004.211h-3.497c.03.514.175.909.437 1.182a1.3 1.3 0 0 0 .979.41c.291 0 .54-.077.745-.231.207-.154.369-.4.49-.737zm-2.606-1.276h2.615c-.035-.395-.136-.691-.3-.888a1.216 1.216 0 0 0-.983-.46c-.365 0-.671.122-.92.366-.247.244-.385.572-.412.982zm6.164 2.086l.109.703a2.951 2.951 0 0 1-.599.071c-.288 0-.511-.045-.671-.137-.158-.092-.27-.211-.335-.36s-.097-.463-.097-.941v-2.705h-.588v-.615h.588v-1.161l.796-.478v1.639h.796v.615h-.796v2.751c0 .228.014.374.042.439a.324.324 0 0 0 .136.155.53.53 0 0 0 .271.057l.347-.032zm.487-1.638c0-.867.241-1.509.725-1.927.403-.347.896-.52 1.476-.52.644 0 1.172.211 1.582.633.409.421.614 1.004.614 1.748 0 .603-.09 1.077-.271 1.422a1.92 1.92 0 0 1-.792.805 2.292 2.292 0 0 1-1.132.286c-.657 0-1.188-.21-1.594-.63-.406-.421-.608-1.027-.608-1.817zm.814.002c0 .6.131 1.05.394 1.347.264.299.594.448.994.448.395 0 .724-.149.988-.449.262-.3.394-.757.394-1.371 0-.579-.133-1.018-.397-1.315a1.261 1.261 0 0 0-.985-.448c-.4 0-.73.148-.994.445-.262.297-.394.745-.394 1.344z" fill="#221F1F"></path></svg>
              
                <svg class="payment-list__item" role="img" aria-labelledby="pi-elo" width="38" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24"><title id="pi-elo">Elo</title><g fill-rule="nonzero" fill="none"><path d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" fill="#000" opacity=".07"></path><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" fill="#FFF"></path><g fill="#000"><path d="M13.3 15.5c-.6.6-1.4.9-2.3.9-.6 0-1.2-.2-1.6-.5l-1.2 1.9c.8.6 1.8.9 2.8.9 1.5 0 2.9-.6 3.9-1.6l-1.6-1.6zm-2.1-7.7c-3 0-5.5 2.4-5.5 5.4 0 1.1.3 2.2.9 3.1l9.8-4.2c-.6-2.5-2.7-4.3-5.2-4.3zm-3.3 5.8v-.4c0-1.8 1.5-3.2 3.2-3.2 1 0 1.8.5 2.4 1.1l-5.6 2.5zm11.6-8.3v10.5l1.8.8-.9 2.1-1.8-.8c-.4-.2-.7-.4-.9-.7-.2-.3-.3-.7-.3-1.3V5.3h2.1zM26 10.2c.3-.1.7-.2 1-.2 1.5 0 2.8 1.1 3.1 2.6l2.2-.4c-.5-2.5-2.7-4.4-5.3-4.4-.6 0-1.2.1-1.7.3l.7 2.1zm-2.6 7.1l1.5-1.7c-.7-.6-1.1-1.4-1.1-2.4s.4-1.8 1.1-2.4l-1.5-1.7c-1.1 1-1.8 2.5-1.8 4.1 0 1.7.7 3.1 1.8 4.1zm6.7-3.4c-.3 1.5-1.6 2.6-3.1 2.6-.4 0-.7-.1-1-.2l-.7 2.1c.5.2 1.1.3 1.7.3 2.6 0 4.8-1.9 5.3-4.4l-2.2-.4z"></path></g></g></svg>
              
                <svg class="payment-list__item" role="img" aria-labelledby="pi-hypercard" viewBox="0 0 38 24" width="38" height="24" xmlns="http://www.w3.org/2000/svg"><title id="pi-hypercard">Hypercard</title><g fill="none" fill-rule="evenodd"><path d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" fill="#000" fill-rule="nonzero" opacity=".07"></path><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" fill="#FFF" fill-rule="nonzero"></path><path d="M11.9 5.1H8.6c-1.4.1-2.6.6-2.9 1.8-.2.6-.3 1.3-.4 2-.7 3.3-1.3 6.7-2 9.9h25.4c2 0 3.3-.4 3.7-2 .2-.7.3-1.5.5-2.3.6-3.1 1.3-6.2 1.9-9.4H11.9z" fill="#B3131B" fill-rule="nonzero"></path><path d="M6.38 9.31h.605v1.827h2.3V9.31h.605v4.421h-.605v-2.067h-2.3v2.067h-.604v-4.42zm4.364 1.213h.551v3.208h-.55v-3.208zm0-1.213h.551v.614h-.55V9.31zm3.36 3.74c.168-.212.252-.528.252-.95 0-.257-.037-.477-.111-.662-.14-.355-.398-.533-.77-.533-.376 0-.633.188-.771.563a2.23 2.23 0 00-.112.765c0 .248.037.46.112.635.14.333.397.5.77.5a.773.773 0 00.63-.318zm-2.032-2.527h.526v.428c.109-.147.227-.26.355-.34.183-.12.398-.181.644-.181.366 0 .676.14.93.42.255.28.383.68.383 1.2 0 .701-.184 1.203-.551 1.504a1.25 1.25 0 01-.813.286c-.242 0-.446-.053-.61-.16a1.408 1.408 0 01-.323-.31v1.646h-.541v-4.493zm5.477.074c.215.107.378.246.49.417.109.162.181.352.217.569.032.148.048.385.048.71h-2.362c.01.327.087.59.232.787.144.197.368.296.67.296.284 0 .51-.093.678-.28a.944.944 0 00.205-.376h.532c-.014.119-.06.25-.14.396a1.432 1.432 0 01-.266.357c-.165.16-.368.268-.61.325a1.873 1.873 0 01-.443.048c-.402 0-.742-.146-1.02-.438-.28-.292-.419-.7-.419-1.227 0-.517.14-.938.421-1.26.281-.324.648-.485 1.102-.485.229 0 .45.054.665.16zm.199 1.265a1.403 1.403 0 00-.154-.562c-.148-.261-.396-.392-.743-.392a.824.824 0 00-.626.27c-.169.18-.258.408-.268.684h1.79zm1.237-1.354h.514v.557c.042-.108.146-.24.31-.396a.804.804 0 01.62-.23l.124.012v.572a.81.81 0 00-.178-.015c-.273 0-.482.088-.629.263a.92.92 0 00-.22.607v1.853h-.541v-3.223zm4.166.172c.228.176.365.48.411.912h-.526a.972.972 0 00-.22-.495c-.115-.132-.298-.198-.55-.198-.346 0-.593.169-.741.506-.097.219-.145.489-.145.81 0 .323.068.594.205.815.136.22.351.331.644.331.225 0 .403-.068.534-.206.132-.137.222-.325.273-.564h.526c-.06.427-.21.74-.451.937-.241.198-.549.297-.924.297-.422 0-.758-.154-1.008-.462-.251-.308-.377-.693-.377-1.154 0-.566.138-1.007.413-1.322a1.332 1.332 0 011.05-.472c.363 0 .659.088.886.265zm1.54 2.564c.114.09.25.135.406.135.19 0 .375-.044.554-.132a.745.745 0 00.451-.72v-.436a.927.927 0 01-.256.106 2.18 2.18 0 01-.307.06l-.328.042a1.255 1.255 0 00-.442.123c-.167.095-.25.245-.25.452 0 .156.057.28.172.37zm1.14-1.466c.125-.016.208-.068.25-.156a.476.476 0 00.036-.208c0-.185-.065-.318-.197-.402-.131-.083-.32-.125-.564-.125-.283 0-.484.077-.602.23a.752.752 0 00-.13.375h-.505c.01-.397.139-.673.387-.829a1.59 1.59 0 01.862-.233c.38 0 .687.072.924.217.235.144.352.369.352.674v1.857c0 .056.012.101.035.135.023.034.071.051.146.051a.824.824 0 00.177-.018v.4c-.084.025-.148.04-.192.046a1.408 1.408 0 01-.181.009c-.187 0-.322-.067-.406-.199a.767.767 0 01-.094-.298c-.11.145-.269.27-.475.376a1.47 1.47 0 01-.683.16c-.3 0-.544-.091-.733-.273a.905.905 0 01-.285-.681c0-.3.094-.531.28-.695.187-.165.432-.266.735-.304l.863-.109zm1.716-1.27h.514v.557c.043-.108.146-.24.31-.396a.804.804 0 01.62-.23l.124.012v.572a.81.81 0 00-.178-.015c-.273 0-.482.088-.629.263a.92.92 0 00-.22.607v1.853h-.541v-3.223zm2.6 2.516c.147.233.381.35.704.35a.745.745 0 00.619-.324c.161-.216.242-.525.242-.929 0-.407-.083-.708-.25-.904a.78.78 0 00-.617-.294.814.814 0 00-.663.313c-.17.21-.255.516-.255.921 0 .345.074.634.22.867zm1.216-2.417c.096.06.206.166.328.316V9.295h.52v4.436h-.487v-.448a1.172 1.172 0 01-.448.43c-.173.089-.37.133-.593.133-.36 0-.67-.151-.933-.453-.263-.302-.394-.704-.394-1.206 0-.469.12-.876.36-1.22.239-.344.582-.516 1.027-.516.247 0 .453.052.62.156z" fill="#FFF"></path></g></svg>
              
                <svg class="payment-list__item" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-master"><title id="pi-master">Mastercard</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><circle fill="#EB001B" cx="15" cy="12" r="7"></circle><circle fill="#F79E1B" cx="23" cy="12" r="7"></circle><path fill="#FF5F00" d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z"></path></svg>
              
                <svg class="payment-list__item" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-visa"><title id="pi-visa">Visa</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><path d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z" fill="#142688"></path></svg>
            </div>
          </div><div class="footer__aside-item footer__aside-item--copyright hidden-lap-and-up">
          <p>© BLACK SKULL BRASIL | <a target="_blank" rel="nofollow" href="https://pt.shopify.com?utm_campaign=poweredby&amp;utm_medium=shopify&amp;utm_source=onlinestore">CNPJ: 37.657.197/0001-46 - BLACK SKULL BRASIL</a></p>
        </div>    

        <div class="footer__aside-item footer__aside-item--localization">
          
          <p class="hidden-pocket">© BLACK SKULL BRASIL | <a target="_blank" rel="nofollow" href="https://pt.shopify.com?utm_campaign=poweredby&amp;utm_medium=shopify&amp;utm_source=onlinestore">CNPJ: 37.657.197/0001-46 - BLACK SKULL BRASIL</a></p>
          
          <!--div class="payment-list">
              
                <svg class="payment-list__item" xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 38 24" width="38" height="24" aria-labelledby="pi-american_express"><title id="pi-american_express">American Express</title><g fill="none"><path fill="#000" d="M35,0 L3,0 C1.3,0 0,1.3 0,3 L0,21 C0,22.7 1.4,24 3,24 L35,24 C36.7,24 38,22.7 38,21 L38,3 C38,1.3 36.6,0 35,0 Z" opacity=".07"></path><path fill="#006FCF" d="M35,1 C36.1,1 37,1.9 37,3 L37,21 C37,22.1 36.1,23 35,23 L3,23 C1.9,23 1,22.1 1,21 L1,3 C1,1.9 1.9,1 3,1 L35,1"></path><path fill="#FFF" d="M8.971,10.268 L9.745,12.144 L8.203,12.144 L8.971,10.268 Z M25.046,10.346 L22.069,10.346 L22.069,11.173 L24.998,11.173 L24.998,12.412 L22.075,12.412 L22.075,13.334 L25.052,13.334 L25.052,14.073 L27.129,11.828 L25.052,9.488 L25.046,10.346 L25.046,10.346 Z M10.983,8.006 L14.978,8.006 L15.865,9.941 L16.687,8 L27.057,8 L28.135,9.19 L29.25,8 L34.013,8 L30.494,11.852 L33.977,15.68 L29.143,15.68 L28.065,14.49 L26.94,15.68 L10.03,15.68 L9.536,14.49 L8.406,14.49 L7.911,15.68 L4,15.68 L7.286,8 L10.716,8 L10.983,8.006 Z M19.646,9.084 L17.407,9.084 L15.907,12.62 L14.282,9.084 L12.06,9.084 L12.06,13.894 L10,9.084 L8.007,9.084 L5.625,14.596 L7.18,14.596 L7.674,13.406 L10.27,13.406 L10.764,14.596 L13.484,14.596 L13.484,10.661 L15.235,14.602 L16.425,14.602 L18.165,10.673 L18.165,14.603 L19.623,14.603 L19.647,9.083 L19.646,9.084 Z M28.986,11.852 L31.517,9.084 L29.695,9.084 L28.094,10.81 L26.546,9.084 L20.652,9.084 L20.652,14.602 L26.462,14.602 L28.076,12.864 L29.624,14.602 L31.499,14.602 L28.987,11.852 L28.986,11.852 Z"></path></g></svg>

              
                <svg class="payment-list__item" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-boleto"><title id="pi-boleto">Boleto</title><path fill="#fff" d="M35.7 23.965H2.3a2.307 2.307 0 0 1-2.3-2.3v-19.4C0 1 1.035-.035 2.3-.035h33.4c1.265 0 2.3 1.035 2.3 2.3v19.4c0 1.265-1.035 2.3-2.3 2.3z"></path><path fill="#A7A8AB" d="M35.564 23.965H2.436c-1.344 0-2.436-1.077-2.436-2.4v-19.2c0-1.323 1.092-2.4 2.436-2.4h33.128c1.344 0 2.436 1.077 2.436 2.4v19.2c0 1.323-1.092 2.4-2.436 2.4zM2.436.925c-.806 0-1.462.646-1.462 1.44v19.2c0 .794.656 1.44 1.462 1.44h33.128c.806 0 1.462-.646 1.462-1.44v-19.2c0-.794-.656-1.44-1.462-1.44H2.436z" opacity=".25"></path><path d="M8.079 4.945h.7v6.298h-.7zm-1.83 0h.7v6.298h-.7zm7.256 0h1.901v6.298h-1.901zm9.715 0h.95v6.298h-.95zm2.324 0h.95v6.298h-.95zm3.804 0h1.221v6.298h-1.221zm-1.375 0h.395v6.298h-.395zm-6.389 0h.395v6.298h-.395zm-.845 0h.395v6.298h-.395zm-2.746 0h.395v6.298h-.395zm-6.31 0h.395v6.298h-.395zm-1.163 0h.733v6.298h-.733zM6.249 19.3v-6.478H8.68c.495 0 .891.065 1.191.196.299.131.532.333.701.606.17.271.255.556.255.855 0 .276-.075.537-.225.781a1.604 1.604 0 0 1-.679.593c.392.115.694.311.903.588.211.276.317.603.317.98 0 .305-.065.587-.193.847a1.644 1.644 0 0 1-.475.603c-.189.14-.425.247-.709.32a4.328 4.328 0 0 1-1.046.109H6.248zm.86-3.755H8.51c.38 0 .653-.026.817-.075a.903.903 0 0 0 .493-.324.936.936 0 0 0 .166-.567 1.03 1.03 0 0 0-.155-.568c-.103-.164-.25-.278-.442-.338s-.52-.09-.985-.09H7.109v1.963zm0 2.995h1.614c.277 0 .472-.011.585-.032.196-.035.362-.094.495-.176a.946.946 0 0 0 .327-.362c.086-.158.128-.341.128-.547 0-.243-.062-.452-.187-.632a.978.978 0 0 0-.516-.377c-.219-.072-.535-.109-.947-.109H7.109v2.235zm4.813-1.588c0-.867.241-1.509.725-1.927.403-.347.896-.52 1.476-.52.644 0 1.172.211 1.582.633.409.421.614 1.004.614 1.748 0 .603-.09 1.077-.271 1.422a1.92 1.92 0 0 1-.792.805 2.292 2.292 0 0 1-1.132.286c-.657 0-1.188-.21-1.594-.63-.406-.421-.608-1.027-.608-1.817zm.814.002c0 .6.131 1.05.394 1.347.264.299.594.448.994.448.395 0 .724-.149.988-.449.262-.3.394-.757.394-1.371 0-.579-.133-1.018-.397-1.315a1.261 1.261 0 0 0-.985-.448c-.4 0-.73.148-.994.445-.262.297-.394.745-.394 1.344zm4.498 2.346v-6.478h.796V19.3h-.796zm5.231-1.52l.823.109c-.128.478-.368.85-.718 1.114-.35.264-.796.397-1.341.397-.685 0-1.227-.211-1.629-.633-.401-.421-.602-1.013-.602-1.775 0-.787.202-1.399.608-1.834.406-.436.932-.653 1.579-.653.626 0 1.137.213 1.534.639.397.427.596 1.027.596 1.8l-.004.211h-3.497c.03.514.175.909.437 1.182a1.3 1.3 0 0 0 .979.41c.291 0 .54-.077.745-.231.207-.154.369-.4.49-.737zm-2.606-1.276h2.615c-.035-.395-.136-.691-.3-.888a1.216 1.216 0 0 0-.983-.46c-.365 0-.671.122-.92.366-.247.244-.385.572-.412.982zm6.164 2.086l.109.703a2.951 2.951 0 0 1-.599.071c-.288 0-.511-.045-.671-.137-.158-.092-.27-.211-.335-.36s-.097-.463-.097-.941v-2.705h-.588v-.615h.588v-1.161l.796-.478v1.639h.796v.615h-.796v2.751c0 .228.014.374.042.439a.324.324 0 0 0 .136.155.53.53 0 0 0 .271.057l.347-.032zm.487-1.638c0-.867.241-1.509.725-1.927.403-.347.896-.52 1.476-.52.644 0 1.172.211 1.582.633.409.421.614 1.004.614 1.748 0 .603-.09 1.077-.271 1.422a1.92 1.92 0 0 1-.792.805 2.292 2.292 0 0 1-1.132.286c-.657 0-1.188-.21-1.594-.63-.406-.421-.608-1.027-.608-1.817zm.814.002c0 .6.131 1.05.394 1.347.264.299.594.448.994.448.395 0 .724-.149.988-.449.262-.3.394-.757.394-1.371 0-.579-.133-1.018-.397-1.315a1.261 1.261 0 0 0-.985-.448c-.4 0-.73.148-.994.445-.262.297-.394.745-.394 1.344z" fill="#221F1F"></path></svg>
              
                <svg class="payment-list__item" role="img" aria-labelledby="pi-elo" width="38" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24"><title id="pi-elo">Elo</title><g fill-rule="nonzero" fill="none"><path d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" fill="#000" opacity=".07"></path><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" fill="#FFF"></path><g fill="#000"><path d="M13.3 15.5c-.6.6-1.4.9-2.3.9-.6 0-1.2-.2-1.6-.5l-1.2 1.9c.8.6 1.8.9 2.8.9 1.5 0 2.9-.6 3.9-1.6l-1.6-1.6zm-2.1-7.7c-3 0-5.5 2.4-5.5 5.4 0 1.1.3 2.2.9 3.1l9.8-4.2c-.6-2.5-2.7-4.3-5.2-4.3zm-3.3 5.8v-.4c0-1.8 1.5-3.2 3.2-3.2 1 0 1.8.5 2.4 1.1l-5.6 2.5zm11.6-8.3v10.5l1.8.8-.9 2.1-1.8-.8c-.4-.2-.7-.4-.9-.7-.2-.3-.3-.7-.3-1.3V5.3h2.1zM26 10.2c.3-.1.7-.2 1-.2 1.5 0 2.8 1.1 3.1 2.6l2.2-.4c-.5-2.5-2.7-4.4-5.3-4.4-.6 0-1.2.1-1.7.3l.7 2.1zm-2.6 7.1l1.5-1.7c-.7-.6-1.1-1.4-1.1-2.4s.4-1.8 1.1-2.4l-1.5-1.7c-1.1 1-1.8 2.5-1.8 4.1 0 1.7.7 3.1 1.8 4.1zm6.7-3.4c-.3 1.5-1.6 2.6-3.1 2.6-.4 0-.7-.1-1-.2l-.7 2.1c.5.2 1.1.3 1.7.3 2.6 0 4.8-1.9 5.3-4.4l-2.2-.4z"></path></g></g></svg>
              
                <svg class="payment-list__item" role="img" aria-labelledby="pi-hypercard" viewBox="0 0 38 24" width="38" height="24" xmlns="http://www.w3.org/2000/svg"><title id="pi-hypercard">Hypercard</title><g fill="none" fill-rule="evenodd"><path d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" fill="#000" fill-rule="nonzero" opacity=".07"></path><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" fill="#FFF" fill-rule="nonzero"></path><path d="M11.9 5.1H8.6c-1.4.1-2.6.6-2.9 1.8-.2.6-.3 1.3-.4 2-.7 3.3-1.3 6.7-2 9.9h25.4c2 0 3.3-.4 3.7-2 .2-.7.3-1.5.5-2.3.6-3.1 1.3-6.2 1.9-9.4H11.9z" fill="#B3131B" fill-rule="nonzero"></path><path d="M6.38 9.31h.605v1.827h2.3V9.31h.605v4.421h-.605v-2.067h-2.3v2.067h-.604v-4.42zm4.364 1.213h.551v3.208h-.55v-3.208zm0-1.213h.551v.614h-.55V9.31zm3.36 3.74c.168-.212.252-.528.252-.95 0-.257-.037-.477-.111-.662-.14-.355-.398-.533-.77-.533-.376 0-.633.188-.771.563a2.23 2.23 0 00-.112.765c0 .248.037.46.112.635.14.333.397.5.77.5a.773.773 0 00.63-.318zm-2.032-2.527h.526v.428c.109-.147.227-.26.355-.34.183-.12.398-.181.644-.181.366 0 .676.14.93.42.255.28.383.68.383 1.2 0 .701-.184 1.203-.551 1.504a1.25 1.25 0 01-.813.286c-.242 0-.446-.053-.61-.16a1.408 1.408 0 01-.323-.31v1.646h-.541v-4.493zm5.477.074c.215.107.378.246.49.417.109.162.181.352.217.569.032.148.048.385.048.71h-2.362c.01.327.087.59.232.787.144.197.368.296.67.296.284 0 .51-.093.678-.28a.944.944 0 00.205-.376h.532c-.014.119-.06.25-.14.396a1.432 1.432 0 01-.266.357c-.165.16-.368.268-.61.325a1.873 1.873 0 01-.443.048c-.402 0-.742-.146-1.02-.438-.28-.292-.419-.7-.419-1.227 0-.517.14-.938.421-1.26.281-.324.648-.485 1.102-.485.229 0 .45.054.665.16zm.199 1.265a1.403 1.403 0 00-.154-.562c-.148-.261-.396-.392-.743-.392a.824.824 0 00-.626.27c-.169.18-.258.408-.268.684h1.79zm1.237-1.354h.514v.557c.042-.108.146-.24.31-.396a.804.804 0 01.62-.23l.124.012v.572a.81.81 0 00-.178-.015c-.273 0-.482.088-.629.263a.92.92 0 00-.22.607v1.853h-.541v-3.223zm4.166.172c.228.176.365.48.411.912h-.526a.972.972 0 00-.22-.495c-.115-.132-.298-.198-.55-.198-.346 0-.593.169-.741.506-.097.219-.145.489-.145.81 0 .323.068.594.205.815.136.22.351.331.644.331.225 0 .403-.068.534-.206.132-.137.222-.325.273-.564h.526c-.06.427-.21.74-.451.937-.241.198-.549.297-.924.297-.422 0-.758-.154-1.008-.462-.251-.308-.377-.693-.377-1.154 0-.566.138-1.007.413-1.322a1.332 1.332 0 011.05-.472c.363 0 .659.088.886.265zm1.54 2.564c.114.09.25.135.406.135.19 0 .375-.044.554-.132a.745.745 0 00.451-.72v-.436a.927.927 0 01-.256.106 2.18 2.18 0 01-.307.06l-.328.042a1.255 1.255 0 00-.442.123c-.167.095-.25.245-.25.452 0 .156.057.28.172.37zm1.14-1.466c.125-.016.208-.068.25-.156a.476.476 0 00.036-.208c0-.185-.065-.318-.197-.402-.131-.083-.32-.125-.564-.125-.283 0-.484.077-.602.23a.752.752 0 00-.13.375h-.505c.01-.397.139-.673.387-.829a1.59 1.59 0 01.862-.233c.38 0 .687.072.924.217.235.144.352.369.352.674v1.857c0 .056.012.101.035.135.023.034.071.051.146.051a.824.824 0 00.177-.018v.4c-.084.025-.148.04-.192.046a1.408 1.408 0 01-.181.009c-.187 0-.322-.067-.406-.199a.767.767 0 01-.094-.298c-.11.145-.269.27-.475.376a1.47 1.47 0 01-.683.16c-.3 0-.544-.091-.733-.273a.905.905 0 01-.285-.681c0-.3.094-.531.28-.695.187-.165.432-.266.735-.304l.863-.109zm1.716-1.27h.514v.557c.043-.108.146-.24.31-.396a.804.804 0 01.62-.23l.124.012v.572a.81.81 0 00-.178-.015c-.273 0-.482.088-.629.263a.92.92 0 00-.22.607v1.853h-.541v-3.223zm2.6 2.516c.147.233.381.35.704.35a.745.745 0 00.619-.324c.161-.216.242-.525.242-.929 0-.407-.083-.708-.25-.904a.78.78 0 00-.617-.294.814.814 0 00-.663.313c-.17.21-.255.516-.255.921 0 .345.074.634.22.867zm1.216-2.417c.096.06.206.166.328.316V9.295h.52v4.436h-.487v-.448a1.172 1.172 0 01-.448.43c-.173.089-.37.133-.593.133-.36 0-.67-.151-.933-.453-.263-.302-.394-.704-.394-1.206 0-.469.12-.876.36-1.22.239-.344.582-.516 1.027-.516.247 0 .453.052.62.156z" fill="#FFF"></path></g></svg>
              
                <svg class="payment-list__item" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-master"><title id="pi-master">Mastercard</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><circle fill="#EB001B" cx="15" cy="12" r="7"></circle><circle fill="#F79E1B" cx="23" cy="12" r="7"></circle><path fill="#FF5F00" d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z"></path></svg>
              
                <svg class="payment-list__item" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-visa"><title id="pi-visa">Visa</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><path d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z" fill="#142688"></path></svg>
              
            </div-->
        </div>

        <div>
        <center><a target="_blank" rel="noopener" style="margin-right: 10px;" aria-describedby="a11y-new-window-message" href="https://www.sslshopper.com/ssl-checker.html#hostname=temadropmetaoficial.myshopify.com"><img src="https://cdn.shopify.com/s/files/1/0453/9770/4859/files/Selos_SSL_1.svg?v=1622577196"></a><a href=""><img src="https://cdn.shopify.com/s/files/1/0453/9770/4859/files/RA-selo-update.svg?v=1622577196" style="margin: 0 15px 0 15px;"></a><a target="_blank" rel="noopener" style="margin-left: 10px;" aria-describedby="a11y-new-window-message" href="https://transparencyreport.google.com/safe-browsing/search?url=temadropmetaoficial.myshopify.com"><img src="https://cdn.shopify.com/s/files/1/0453/9770/4859/files/Selos_Google_1.svg?v=1622577196" ></a></center>
        </div>

      </aside>
      
    </div>
  </div><aside class="cookie-bar" aria-hidden="true">
      <div class="container">
        <div class="cookie-bar__inner">
          <div class="cookie-bar__text rte"><p>Utilizamos cookies para melhorar nosso site e sua experiência de compra. Ao continuar navegando em nosso site,<strong>você está de acordo conforme nossa política quando a utilização de cookies.</strong></p></div><button type="button" class="cookie-bar__button button button--secondary" data-action="accept-terms">ENTENDI E FECHAR</button></div>
      </div>
    </aside></footer>

</div>
<style>
  
  :root {
  
  --imagezap-background: url(//cdn.shopify.com/shopifycloud/shopify/assets/no-image-2048-5e88c1b20e087fb7bbe9a3771824e743c244f437e4f8ba93bbf7b11b53f7824c.gif);
  --colorzap-color: #00d864;
    
  }
    
  .hidden {
	display: none;
}

.sticky-button {
  
    position: fixed;
    background: none var(--imagezap-background);
    background-size: contain;
    background-repeat: no-repeat;
    bottom: 20px;
    right: 20px;
    border-radius: 50px;
    box-shadow: 0 0px 12px 0 rgb(0 0 0 / 10%);
    z-index: 20;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 55px;
    height: 55px;
    -webkit-transition: all 0.2s ease-out;
    transition: all 0.2s ease-out;
      
}

.sticky-button svg {
	margin: auto;
	fill: #fff;
    width: 35px;
	height: 35px;
}

.sticky-button a,.sticky-button label {
    
	cursor: pointer;
	display: flex;
	align-items: center;
	width: 55px;
	height: 65px;
	-webkit-transition: all .3s ease-out;
	transition: all .3s ease-out;
}

.sticky-button label svg.close-icon {
	display: none;
}

.sticky-chat {
	position: fixed;
	bottom: 85px;
	right: 20px;
	width: 320px;
	-webkit-transition: all .3s ease-out;
	transition: all .3s ease-out;
	z-index: 21;
	opacity: 0;
	visibility: hidden;
}

.sticky-chat a {
  text-decoration: none;
  font-family: 'Roboto',sans-serif;
  color: #505050;
  
}

.sticky-chat svg {
	width: 35px;
	height: 35px;
}

.sticky-chat .chat-content {
	border-radius: 14px;
    background-color: #bac1d1b8;
    backdrop-filter: blur(5px);
	overflow: hidden;
	font-family: var(--text-font-family);
	font-weight: 400;
}

.sticky-chat .chat-header {
	position: relative;
	display: flex;
	align-items: center;
	padding: 15px 20px;
	background-color: var(--colorzap-color);
	overflow: hidden;
}

.sticky-chat .chat-header:after {
	content: '';
	display: block;
	position: absolute;
	bottom: 0;
	right: 0;
	width: 80px;
	height: 75px;
	background: rgba(0,0,0,.040);
	border-radius: 70px 0 5px 0;
}

.sticky-chat .chat-header svg {
	width: 35px;
	height: 35px;
	flex: 0 0 auto;
	fill: #fff;
}

.sticky-chat .chat-header .title {
	padding-left: 15px;
	font-size: 14px;
	font-weight: 600;
	font-family: var(--heading-font-family);
  color: #fff;
}

.sticky-chat .chat-header .title span {
	font-size: 11px;
	font-weight: 400;
	display: block;
	line-height: 1.58em;
	margin: 0;
	color: #f4f4f4;
}

.sticky-chat .chat-text {
	display: flex;
	flex-wrap: wrap;
	margin: 30px 20px;
	font-size: 12px;
}

.sticky-chat .chat-text span {
	display: inline-block;
	margin-right: auto;
	padding: 10px;
    height: fit-content;
	background-color: #f0f5fb;
	border-radius: 0px 15px 15px;
}

.sticky-chat .chat-text span:after {
	content: 'agora mesmo';
	display: inline-block;
	margin-left: 10px;
	font-size: 9px;
	color: #989b9f;
}

.sticky-chat .chat-text span.typing {
	margin: 15px 0 0 auto;
	padding: 4px;
	border-radius: 15px 0px 15px 15px;
}

.sticky-chat .chat-text span.typing:after {
	display: none;
}

.sticky-chat .chat-text span.typing svg {
	height: 13px;
	fill: #505050;
}

.sticky-chat .chat-button {
  
	display: block;
	align-items: center;
	margin-top: 5px;
	padding: 10px;
	border-radius: 14px;
    background-color: #bac1d1b8;
    backdrop-filter: blur(5px);
	overflow: hidden;
	font-size: 12px;
	font-family: var(--text-font-family);
	font-weight: 400;
  
}

.sticky-chat .chat-button svg {
	width: 20px;
	height: 20px;
	fill: #505050;
	margin-left: auto;
	transform: rotate(40deg);
	-webkit-transform: rotate(40deg);
}

.chat-menu:checked+.sticky-button label {
	-webkit-transform: rotate(360deg);
	transform: rotate(360deg);
}

.chat-menu:checked+.sticky-button label svg.chat-icon {
	display: none;
}

.chat-menu:checked+.sticky-button label svg.close-icon {
	display: table-cell;
}

.chat-menu:checked+.sticky-button+.sticky-chat {
  
bottom: 88px;
    right: 18px;
	opacity: 1;
	visibility: visible;
  
}
  
    .wa-chat-widget-send form {
        
      display: flex;
      margin: 0;
        
    }

    .wa-chat-widget-send input {
      
    background: #f0f5fb;
    border: 0;
    border-right: 1px solid #dee6ef;
      color: #c1c5ca;
    padding: 0.5rem 1.2rem;
    width: 100%;
    border-radius: 10px 0 0 10px;
      
    }

    .wa-chat-widget-send button {
      
      background-color: #f0f5fb;
      padding: 0.5rem;
      padding-top: 11px;
      padding-right: 15px;
      border-radius: 0 10px 10px 0;
      border: none;
      fill: #ffffff;
      
    }

    @keyframes wa-chat-animation {
      from {
        opacity: 0;
      }
    }
    
    @media (max-width: 768px) {
    
    .sticky-button {
      
    bottom: 64px;

}
      .chat-menu:checked+.sticky-button+.sticky-chat {
        
	bottom: 125px;
    right: 21px;

}
    
    }
    
  
</style>

<input class="chat-menu hidden" id="offchat-menu" type="checkbox"/>
<div class="sticky-button" id="sticky-button">
	<label for="offchat-menu">
      
<img src="//cdn.shopify.com/s/files/1/0629/7449/2915/t/6/assets/whatsapp.svg?v=8122552569372891836" alt="WhatsApp">
      
		<svg class="close-icon" viewBox="0 0 512 512">
			<path d="M278.6 256l68.2-68.2c6.2-6.2 6.2-16.4 0-22.6-6.2-6.2-16.4-6.2-22.6 0L256 233.4l-68.2-68.2c-6.2-6.2-16.4-6.2-22.6 0-3.1 3.1-4.7 7.2-4.7 11.3 0 4.1 1.6 8.2 4.7 11.3l68.2 68.2-68.2 68.2c-3.1 3.1-4.7 7.2-4.7 11.3 0 4.1 1.6 8.2 4.7 11.3 6.2 6.2 16.4 6.2 22.6 0l68.2-68.2 68.2 68.2c6.2 6.2 16.4 6.2 22.6 0 6.2-6.2 6.2-16.4 0-22.6L278.6 256z"/>
		</svg>
	</label>
</div>
<div class="sticky-chat">
	<div class="chat-content">
		<div class="chat-header">
          
			<svg viewBox="0 0 32 32">
				<path d="M24,22a1,1,0,0,1-.64-.23L18.84,18H17A8,8,0,0,1,17,2h6a8,8,0,0,1,2,15.74V21a1,1,0,0,1-.58.91A1,1,0,0,1,24,22ZM17,4a6,6,0,0,0,0,12h2.2a1,1,0,0,1,.64.23L23,18.86V16.92a1,1,0,0,1,.86-1A6,6,0,0,0,23,4Z"/>
				<rect height="2" width="2" x="19" y="9"></rect>
				<rect height="2" width="2" x="14" y="9"></rect>
				<rect height="2" width="2" x="24" y="9"></rect>
				<path d="M8,30a1,1,0,0,1-.42-.09A1,1,0,0,1,7,29V25.74a8,8,0,0,1-1.28-15,1,1,0,1,1,.82,1.82,6,6,0,0,0,1.6,11.4,1,1,0,0,1,.86,1v1.94l3.16-2.63A1,1,0,0,1,12.8,24H15a5.94,5.94,0,0,0,4.29-1.82,1,1,0,0,1,1.44,1.4A8,8,0,0,1,15,26H13.16L8.64,29.77A1,1,0,0,1,8,30Z"/>
			</svg>
          
			<div class="title">Fale Conosco 
<span>
O melhor suporte é com a BLACK SKULL BRASIL.
</span></div>
          
		</div>
      
		<div class="chat-text"><span>Olá, estou aqui para te ajudar!</span>
      <span class="typing">
        <svg viewBox="0 0 512 512">
          <circle cx="256" cy="256" r="48"></circle>
          <circle cx="416" cy="256" r="48"></circle>
          <circle cx="96" cy="256" r="48"></circle>
        </svg>
       </span>
      </div>
	  </div>
        <div class="chat-button wa-chat-widget-send">
      <form autocomplete="off" target="_blank" method="get" action="https://wa.me/5521959515865">
        <input type="text" name="text" placeholder="Digite sua mensagem..." />
        <button type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
            <path
              d="M24 0l-6 22-8.129-7.239 7.802-8.234-10.458 7.227-7.215-1.754 24-12zm-15 16.668v7.332l3.258-4.431-3.258-2.901z" />
          </svg></button> 
      </form>
    </div>    
        
<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '3429910793997552');
  fbq('track', 'PageView');
  fbq('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=3429910793997552&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '');
  fbq('track', 'PageView');
  
  fbq('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '');
  fbq('track', 'PageView');
  fbq('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
  </div> </body>
</html>